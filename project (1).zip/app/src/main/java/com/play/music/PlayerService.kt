package com.play.music

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

object Sleep {
    private val h = Handler(Looper.getMainLooper())
    var endAt by mutableLongStateOf(0L)
    var total by mutableLongStateOf(1L)
    fun start(min: Int) {
        cancel()
        total = min * 60000L
        endAt = System.currentTimeMillis() + total
        h.postDelayed({ PlayerService.player?.pause(); endAt = 0L }, total)
    }
    fun cancel() {
        h.removeCallbacksAndMessages(null)
        endAt = 0L
    }
}

class PlayerService : MediaSessionService() {
    private var session: MediaSession? = null
    private val hand = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (player?.isPlaying == true) WidgetHelper.update(this@PlayerService, true)
            hand.postDelayed(this, 1000)
        }
    }

    companion object {
        var player: ExoPlayer? = null
        var eq: Equalizer? = null
        var bass: BassBoost? = null
        var sid = 0
    }

    override fun onCreate() {
        super.onCreate()
        val p = ExoPlayer.Builder(this)
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        sid = (getSystemService(Context.AUDIO_SERVICE) as AudioManager).generateAudioSessionId()
        p.setAudioSessionId(sid)
        val sp = getSharedPreferences("play", Context.MODE_PRIVATE)
        try {
            val e = Equalizer(0, sid)
            val lv = (sp.getString("eq", "") ?: "").split(",").mapNotNull { it.toShortOrNull() }
            if (lv.size == e.numberOfBands.toInt()) lv.forEachIndexed { i, v -> e.setBandLevel(i.toShort(), v) }
            e.setEnabled(sp.getBoolean("eq_on", true))
            eq = e
        } catch (ex: Exception) {
        }
        try {
            val b = BassBoost(0, sid)
            if (b.getStrengthSupported()) b.setStrength(sp.getInt("bass", 0).toShort())
            b.setEnabled(true)
            bass = b
        } catch (ex: Exception) {
        }
        p.addListener(object : Player.Listener {
            override fun onEvents(pl: Player, e: Player.Events) {
                if (e.containsAny(Player.EVENT_IS_PLAYING_CHANGED, Player.EVENT_MEDIA_ITEM_TRANSITION, Player.EVENT_MEDIA_METADATA_CHANGED)) {
                    WidgetHelper.update(this@PlayerService)
                }
                if (e.contains(Player.EVENT_IS_PLAYING_CHANGED) && !pl.isPlaying) saveLast(this@PlayerService, pl)
            }
        })
        player = p
        session = MediaSession.Builder(this, p).build()
        WidgetHelper.update(this)
        hand.postDelayed(tick, 1000)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        player?.let { saveLast(this, it) }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        hand.removeCallbacksAndMessages(null)
        player?.let { saveLast(this, it) }
        try { eq?.release() } catch (e: Exception) {}
        try { bass?.release() } catch (e: Exception) {}
        eq = null
        bass = null
        player = null
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        WidgetHelper.update(this)
        super.onDestroy()
    }
}
