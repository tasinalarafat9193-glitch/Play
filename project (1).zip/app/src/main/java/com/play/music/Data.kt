package com.play.music

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.Player
import org.json.JSONArray
import org.json.JSONObject

data class Song(
    val id: Long, val title: String, val artist: String, val album: String,
    val added: Long, val dur: Long, val size: Long, val file: String, val path: String, val uri: Uri
) {
    val dir: String get() = path.substringBeforeLast('/', "")
}

fun letterOf(t: String): Char {
    val c = t.firstOrNull()?.uppercaseChar() ?: '#'
    return if (c in 'A'..'Z') c else '#'
}

fun cl(s: String?, d: String): String = if (s.isNullOrBlank() || s == "<unknown>") d else s

fun loadSongs(c: Context): List<Song> {
    val out = mutableListOf<Song>()
    val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DATA
    )
    try {
        c.contentResolver.query(base, proj, MediaStore.Audio.Media.DURATION + " >= 30000", null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")?.use { q ->
            while (q.moveToNext()) {
                val id = q.getLong(0)
                out.add(
                    Song(
                        id, cl(q.getString(1), "Unknown").replace('_', ' '), cl(q.getString(2), "Unknown Artist"),
                        cl(q.getString(3), "Unknown Album"), q.getLong(4), q.getLong(5), q.getLong(6),
                        q.getString(7) ?: "", q.getString(8) ?: "", ContentUris.withAppendedId(base, id)
                    )
                )
            }
        }
    } catch (e: Exception) {
    }
    return out
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

fun hz(mHz: Int): String {
    val h = mHz / 1000
    return if (h >= 1000) "%.1f kHz".format(h / 1000.0) else "$h Hz"
}

fun saveLast(c: Context, p: Player) {
    try {
        if (p.mediaItemCount == 0) return
        val ids = List(minOf(p.mediaItemCount, 3000)) { p.getMediaItemAt(it).mediaId.toLongOrNull() ?: -1L }
        Store(c).saveLast(ids, p.currentMediaItem?.mediaId?.toLongOrNull() ?: -1L, p.currentPosition)
    } catch (e: Exception) {
    }
}

class Store(c: Context) {
    private val sp = c.getSharedPreferences("play", Context.MODE_PRIVATE)

    fun favs(): Set<Long> = (sp.getStringSet("favs", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
    fun saveFavs(s: Set<Long>) {
        sp.edit().putStringSet("favs", s.map { it.toString() }.toSet()).apply()
    }

    fun playlists(): Map<String, List<Long>> {
        val r = LinkedHashMap<String, List<Long>>()
        try {
            val o = JSONObject(sp.getString("pl", "{}") ?: "{}")
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                r[k] = List(a.length()) { a.getLong(it) }
            }
        } catch (e: Exception) {
        }
        return r
    }

    fun savePlaylists(m: Map<String, List<Long>>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        sp.edit().putString("pl", o.toString()).apply()
    }

    fun counts(): Map<Long, Int> {
        val r = HashMap<Long, Int>()
        (sp.getString("counts", "") ?: "").split(",").forEach {
            val p = it.split(":")
            if (p.size == 2) {
                val k = p[0].toLongOrNull()
                val v = p[1].toIntOrNull()
                if (k != null && v != null) r[k] = v
            }
        }
        return r
    }

    fun saveCounts(m: Map<Long, Int>) {
        sp.edit().putString("counts", m.entries.joinToString(",") { "${it.key}:${it.value}" }).apply()
    }

    var sort: Int
        get() = sp.getInt("sort", 0)
        set(v) { sp.edit().putInt("sort", v).apply() }
    var visual: Int
        get() = sp.getInt("visual", 0)
        set(v) { sp.edit().putInt("visual", v).apply() }
    var shuf: Boolean
        get() = sp.getBoolean("shuf", false)
        set(v) { sp.edit().putBoolean("shuf", v).apply() }
    var rpt: Int
        get() = sp.getInt("rpt", 0)
        set(v) { sp.edit().putInt("rpt", v).apply() }
    var bass: Int
        get() = sp.getInt("bass", 0)
        set(v) { sp.edit().putInt("bass", v).apply() }
    var tAccent: Int
        get() = sp.getInt("t_a", 0xFF22E6FF.toInt())
        set(v) { sp.edit().putInt("t_a", v).apply() }
    var tAccent2: Int
        get() = sp.getInt("t_b", 0xFFFF2D55.toInt())
        set(v) { sp.edit().putInt("t_b", v).apply() }
    var tTint: Int
        get() = sp.getInt("t_t", 0xFF0B1C4D.toInt())
        set(v) { sp.edit().putInt("t_t", v).apply() }
    var tGrad: Boolean
        get() = sp.getBoolean("t_g", true)
        set(v) { sp.edit().putBoolean("t_g", v).apply() }

    fun saveEq(levels: List<Int>, on: Boolean) {
        sp.edit().putString("eq", levels.joinToString(",")).putBoolean("eq_on", on).apply()
    }

    fun saveLast(ids: List<Long>, id: Long, pos: Long) {
        sp.edit().putString("last_ids", ids.joinToString(",")).putLong("last_id", id).putLong("last_pos", pos).apply()
    }

    fun lastIds(): List<Long> = (sp.getString("last_ids", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }
    val lastId: Long get() = sp.getLong("last_id", -1L)
    val lastPos: Long get() = sp.getLong("last_pos", 0L)
}
