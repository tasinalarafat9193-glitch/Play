package com.play.music

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun Splash(onDone: () -> Unit) {
    val p = remember { Animatable(0f) }
    val lay = remember { Animatable(0f) }
    val drop = remember { Animatable(-1f) }
    val fade = remember { Animatable(1f) }
    var lw by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        launch { p.animateTo(1f, tween(380, easing = FastOutSlowInEasing)) }
        delay(320)
        launch { lay.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }
        drop.animateTo(0f, tween(400, easing = FastOutLinearInEasing))
        drop.animateTo(-0.22f, tween(170, easing = LinearOutSlowInEasing))
        drop.animateTo(0f, tween(170, easing = FastOutLinearInEasing))
        drop.animateTo(-0.07f, tween(110, easing = LinearOutSlowInEasing))
        drop.animateTo(0f, tween(110, easing = FastOutLinearInEasing))
        delay(420)
        fade.animateTo(0f, tween(400))
        onDone()
    }
    Box(
        Modifier.fillMaxSize().graphicsLayer { alpha = fade.value }.background(bgBrush()).pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                "P", color = Cyan, fontSize = 64.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.graphicsLayer {
                    alpha = p.value; scaleX = 0.8f + 0.2f * p.value; scaleY = 0.8f + 0.2f * p.value
                }
            )
            Box(Modifier.clipToBounds().onSizeChanged { lw = it.width }) {
                Text(
                    "lay", color = Cyan, fontSize = 64.sp, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.graphicsLayer {
                        translationX = -(1f - lay.value) * lw
                        alpha = if (lw > 0) 1f else 0f
                    }
                )
            }
            Box(
                Modifier.padding(start = 4.dp, bottom = 18.dp).offset(y = 180.dp * drop.value)
                    .graphicsLayer { alpha = if (drop.value > -0.98f) 1f else 0f }
                    .size(14.dp).clip(CircleShape).background(Red)
            )
        }
    }
}
