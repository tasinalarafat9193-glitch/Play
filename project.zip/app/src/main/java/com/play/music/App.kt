package com.play.music

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.result.ActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class Sheet {
    data class Menu(val s: Song, val fromPlayer: Boolean = false) : Sheet()
    object SortBy : Sheet()
    object SleepT : Sheet()
    object Equal : Sheet()
    object QueueL : Sheet()
    object SpeedS : Sheet()
    data class AddTo(val ids: List<Long>) : Sheet()
    data class NewPl(val ids: List<Long>) : Sheet()
}

@Stable
class App(val ctx: Context, val store: Store) {
    lateinit var scope: CoroutineScope
    val exp = Animatable(0f)
    var hPx by mutableFloatStateOf(2000f)
    var hdrH by mutableIntStateOf(0)
    var songs by mutableStateOf<List<Song>>(emptyList())
    var loaded by mutableStateOf(false)
    var granted by mutableStateOf(hasPerm())
    var favs by mutableStateOf(store.favs())
    var lists by mutableStateOf(store.playlists())
    var counts by mutableStateOf(store.counts())
    var sort by mutableIntStateOf(store.sort)
    var visual by mutableIntStateOf(store.visual)
    var q by mutableStateOf("")
    var searching by mutableStateOf(false)
    var openList by mutableStateOf<String?>(null)
    var openFolder by mutableStateOf<String?>(null)
    var sel by mutableStateOf<Set<Long>>(emptySet())
    var ctl by mutableStateOf<MediaController?>(null)
    var curId by mutableStateOf<Long?>(null)
    var title by mutableStateOf("")
    var artist by mutableStateOf("")
    var playing by mutableStateOf(false)
    var pos by mutableLongStateOf(0L)
    var dur by mutableLongStateOf(0L)
    var drag by mutableStateOf(false)
    var shuffle by mutableStateOf(false)
    var rep by mutableIntStateOf(0)
    var speed by mutableFloatStateOf(1f)
    var queue by mutableStateOf<List<MediaItem>>(emptyList())
    var sheet by mutableStateOf<Sheet?>(null)
    var info by mutableStateOf<Song?>(null)
    var about by mutableStateOf(false)
    var miniShown by mutableStateOf(false)
    var startTick by mutableIntStateOf(0)
    var removing by mutableStateOf<Set<Long>>(emptySet())
    var stamp = 0L
    var ready by mutableStateOf(false)
    var readyAt = 0L
    var page by mutableStateOf<String?>(null)
    var curPage by mutableIntStateOf(0)
    var noteOn by mutableStateOf(false)
    var noteText by mutableStateOf("")
    private var noteJob: Job? = null
    var iconColor by mutableStateOf(Pal10[0])
    private var cycleQ = mutableListOf<Color>()
    val animated = HashSet<String>()
    var counted: Long? = null
    var restored = false
    var pendingDelete: List<Song> = emptyList()
    var delLauncher: ManagedActivityResultLauncher<IntentSenderRequest, ActivityResult>? = null
    var askPerm: () -> Unit = {}

    init {
        Theme.accent = Color(store.tAccent)
        Theme.accent2 = Color(store.tAccent2)
        Theme.tint = Color(store.tTint)
        Theme.gradient = store.tGrad
    }

    val perm: String get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    fun hasPerm(): Boolean = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
    val byId: Map<Long, Song> get() = songs.associateBy { it.id }
    val expanded: Boolean get() = exp.value > 0.5f

    fun nextColor(): Color {
        if (cycleQ.isEmpty()) cycleQ = (listOf(Pal10[0]) + Pal10.drop(1).shuffled()).toMutableList()
        return cycleQ.removeAt(0)
    }

    fun showNote(t: String) {
        noteJob?.cancel()
        noteJob = scope.launch { noteText = t; noteOn = true; delay(1700); noteOn = false }
    }

    fun shareMany(l: List<Song>) {
        if (l.isEmpty()) return
        if (l.size == 1) { share(l[0]); return }
        val i = Intent(Intent.ACTION_SEND_MULTIPLE)
        i.type = "audio/*"
        i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(l.map { it.uri }))
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    fun expand() { scope.launch { exp.animateTo(1f, spring(dampingRatio = 0.9f, stiffness = 260f)) } }
    fun collapse() { scope.launch { exp.animateTo(0f, spring(dampingRatio = 0.9f, stiffness = 260f)) } }

    fun reload() {
        scope.launch {
            granted = hasPerm()
            if (!granted) { loaded = true; return@launch }
            val l = withContext(Dispatchers.IO) { loadSongs(ctx) }
            songs = l
            loaded = true
            sel = emptySet()
            restore()
        }
    }

    private fun filt(l: List<Song>): List<Song> =
        if (q.isBlank()) l else l.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }

    fun tracks(): List<Song> {
        val f = filt(songs)
        return when (sort) {
            1 -> f.sortedByDescending { it.added }
            2 -> f.sortedWith(compareByDescending<Song> { counts[it.id] ?: 0 }.thenBy { it.title.lowercase() })
            else -> f.sortedBy { it.title.lowercase() }
        }
    }

    fun favSongs(): List<Song> = filt(songs.filter { it.id in favs }).sortedBy { it.title.lowercase() }
    fun playlistSongs(name: String): List<Song> { val m = byId; return filt((lists[name] ?: emptyList()).mapNotNull { m[it] }) }
    fun folderSongs(dir: String): List<Song> = filt(songs.filter { it.dir == dir }).sortedBy { it.title.lowercase() }
    fun folders(): List<Pair<String, List<Song>>> = songs.groupBy { it.dir }.entries.sortedBy { it.key.substringAfterLast('/').lowercase() }.map { it.key to it.value }

    fun item(s: Song): MediaItem = MediaItem.Builder().setMediaId(s.id.toString()).setUri(s.uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).build()).build()

    fun playList(l: List<Song>, i: Int) {
        val c = ctl ?: return
        if (l.isEmpty()) return
        c.setMediaItems(l.map { item(it) }, i, 0L)
        c.prepare()
        c.play()
    }

    fun playNext(s: Song) {
        val c = ctl ?: return
        if (c.mediaItemCount == 0) playList(listOf(s), 0) else { c.addMediaItem(c.currentMediaItemIndex + 1, item(s)); toast("Will play next") }
    }

    fun addQueue(s: Song) {
        val c = ctl ?: return
        if (c.mediaItemCount == 0) playList(listOf(s), 0) else { c.addMediaItem(item(s)); toast("Added to queue") }
    }

    fun toggleSel(id: Long) { sel = if (id in sel) sel - id else sel + id }
    fun toggleFav(id: Long) { favs = if (id in favs) favs - id else favs + id; store.saveFavs(favs) }

    fun addToPlaylist(name: String, ids: List<Long>) {
        val old = lists[name] ?: emptyList()
        lists = lists + (name to (old + ids.filter { it !in old }))
        store.savePlaylists(lists)
    }

    fun deletePlaylist(name: String) { lists = lists - name; store.savePlaylists(lists) }

    fun removeFromPlaylist(name: String, ids: Set<Long>) {
        lists = lists + (name to (lists[name] ?: emptyList()).filter { it !in ids })
        store.savePlaylists(lists)
        sel = emptySet()
    }

    fun bump(id: Long) {
        counts = counts + (id to ((counts[id] ?: 0) + 1))
        store.saveCounts(counts)
    }

    fun changeSpeed(f: Float) { ctl?.setPlaybackSpeed(f); speed = f }

    fun saveTheme() {
        store.tAccent = Theme.accent.toArgb()
        store.tAccent2 = Theme.accent2.toArgb()
        store.tTint = Theme.tint.toArgb()
        store.tGrad = Theme.gradient
    }

    fun attach(c: MediaController) {
        ctl = c
        c.setShuffleModeEnabled(store.shuf)
        c.setRepeatMode(store.rpt)
        c.addListener(object : Player.Listener {
            override fun onEvents(p: Player, e: Player.Events) { sync(p, e.contains(Player.EVENT_TIMELINE_CHANGED)) }
        })
        sync(c, true)
        restore()
    }

    fun sync(p: Player, tl: Boolean) {
        playing = p.isPlaying
        val id = p.currentMediaItem?.mediaId?.toLongOrNull()
        if (id != curId) { counted = null; if (id != null) iconColor = nextColor() }
        curId = id
        title = p.mediaMetadata.title?.toString() ?: ""
        artist = p.mediaMetadata.artist?.toString() ?: ""
        dur = maxOf(p.duration, 0L)
        shuffle = p.shuffleModeEnabled
        rep = p.repeatMode
        speed = p.playbackParameters.speed
        if (tl) queue = List(p.mediaItemCount) { p.getMediaItemAt(it) }
    }

    fun restore() {
        val c = ctl ?: return
        if (restored || !loaded || songs.isEmpty()) return
        restored = true
        if (c.mediaItemCount > 0) return
        val m = byId
        val list = store.lastIds().mapNotNull { m[it] }
        if (list.isEmpty()) return
        val idx = list.indexOfFirst { it.id == store.lastId }.coerceAtLeast(0)
        c.setMediaItems(list.map { item(it) }, idx, store.lastPos)
        c.prepare()
    }

    fun saveState() { ctl?.let { saveLast(ctx, it) } }

    fun deleteSongs(l: List<Song>) {
        if (l.isEmpty()) return
        pendingDelete = l
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, l.map { it.uri })
                delLauncher?.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) { toast("Couldn’t delete") }
        } else {
            val ok = mutableListOf<Song>()
            l.forEach { try { ctx.contentResolver.delete(it.uri, null, null); ok.add(it) } catch (e: Exception) {} }
            if (ok.isNotEmpty()) { pendingDelete = ok; finishDelete() } else toast("Couldn’t delete")
        }
    }

    fun finishDelete() {
        val ids = pendingDelete.map { it.id }.toSet()
        pendingDelete = emptyList()
        removing = ids
        sel = emptySet()
        scope.launch {
            delay(380)
            songs = songs.filter { it.id !in ids }
            removing = emptySet()
        }
    }

    fun ringtone(s: Song) {
        try {
            if (!Settings.System.canWrite(ctx)) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                toast("Allow “Modify system settings”, then try again")
                return
            }
            RingtoneManager.setActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_RINGTONE, s.uri)
            toast("Ringtone set")
        } catch (e: Exception) { toast("Couldn’t set ringtone") }
    }

    fun share(s: Song) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "audio/*"
        i.putExtra(Intent.EXTRA_STREAM, s.uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
