package com.play.music

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject

data class Song(
    val id: Long, val title: String, val artist: String, val album: String,
    val added: Long, val dur: Long, val size: Long, val file: String, val path: String, val uri: Uri
)

fun cl(s: String?, d: String): String = if (s.isNullOrBlank() || s == "<unknown>") d else s

fun loadSongs(c: Context): List<Song> {
    val out = mutableListOf<Song>()
    val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DATA
    )
    c.contentResolver.query(base, proj, MediaStore.Audio.Media.DURATION + " >= 30000", null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")?.use { q ->
        while (q.moveToNext()) {
            val id = q.getLong(0)
            out.add(
                Song(
                    id, cl(q.getString(1), "Unknown").replace('_', ' '), cl(q.getString(2), "Unknown Artist"),
                    cl(q.getString(3), "Unknown Album"), q.getLong(4), q.getLong(5), q.getLong(6),
                    q.getString(7) ?: "", q.getString(8) ?: "", ContentUris.withAppendedId(base, id)
                )
            )
        }
    }
    return out
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

fun hz(mHz: Int): String {
    val h = mHz / 1000
    return if (h >= 1000) "%.1f kHz".format(h / 1000.0) else "$h Hz"
}

class Store(c: Context) {
    private val sp = c.getSharedPreferences("play", Context.MODE_PRIVATE)

    fun favs(): Set<Long> = (sp.getStringSet("favs", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
    fun saveFavs(s: Set<Long>) {
        sp.edit().putStringSet("favs", s.map { it.toString() }.toSet()).apply()
    }

    fun playlists(): Map<String, List<Long>> {
        val r = LinkedHashMap<String, List<Long>>()
        try {
            val o = JSONObject(sp.getString("pl", "{}") ?: "{}")
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                r[k] = List(a.length()) { a.getLong(it) }
            }
        } catch (e: Exception) {
        }
        return r
    }

    fun savePlaylists(m: Map<String, List<Long>>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        sp.edit().putString("pl", o.toString()).apply()
    }

    var sort: Int
        get() = sp.getInt("sort", 0)
        set(v) {
            sp.edit().putInt("sort", v).apply()
        }

    fun saveEq(levels: List<Int>, on: Boolean) {
        sp.edit().putString("eq", levels.joinToString(",")).putBoolean("eq_on", on).apply()
    }
}
