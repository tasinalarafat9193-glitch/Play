@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.play.music

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

@Composable
fun Chip(text: String, on: Boolean, color: Color = Cyan, onClick: () -> Unit) {
    Box(
        Modifier.bounceClick(onClick = onClick).clip(RoundedCornerShape(999.dp)).background(Color(0xFF111A30))
            .border(1.dp, if (on) color else LineC, RoundedCornerShape(999.dp)).padding(horizontal = 16.dp, vertical = 10.dp)
    ) { Text(text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = color) }
}

@Composable
fun TopIcon(icon: ImageVector, desc: String, tint: Color = Cyan, ring: Float = -1f, onClick: () -> Unit) {
    Box(
        Modifier.size(38.dp).bounceClick(onClick = onClick).clip(CircleShape).background(Color(0xFF0F1830)).border(1.dp, LineC, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (ring >= 0f) Canvas(Modifier.fillMaxSize()) {
            val sw = 2.5.dp.toPx()
            drawArc(Cyan, -90f, 360f * ring, false, topLeft = Offset(sw / 2, sw / 2), size = Size(size.width - sw, size.height - sw), style = Stroke(sw, cap = StrokeCap.Round))
        }
        Icon(icon, desc, tint = tint, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun SleepTopIcon(a: App) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Sleep.endAt) { while (Sleep.endAt > 0) { now = System.currentTimeMillis(); delay(90) } }
    val ring = if (Sleep.endAt > 0) ((Sleep.endAt - now).toFloat() / Sleep.total).coerceIn(0f, 1f) else -1f
    TopIcon(Icons.Rounded.Schedule, "Sleep timer", Cyan, ring) { a.sheet = Sheet.SleepT }
}

@Composable
fun Header(a: App, pager: PagerState, onTab: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().onSizeChanged { a.hdrH = it.height }) {
        Box(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 14.dp), contentAlignment = Alignment.CenterStart) {
            Crossfade(targetState = if (a.sel.isNotEmpty()) 2 else if (a.searching) 1 else 0, animationSpec = tween(260), label = "hdr") { m ->
                when (m) {
                    0 -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Play", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Text(".", color = Red, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.weight(1f))
                        TopIcon(Icons.Rounded.Search, "Search") { a.searching = true }
                        Spacer(Modifier.width(6.dp))
                        TopIcon(Icons.Rounded.Sort, "Sort") { a.sheet = Sheet.SortBy }
                        Spacer(Modifier.width(6.dp))
                        SleepTopIcon(a)
                        Spacer(Modifier.width(6.dp))
                        TopIcon(Icons.Rounded.GraphicEq, "Equalizer") { a.sheet = Sheet.Equal }
                        Spacer(Modifier.width(6.dp))
                        TopIcon(Icons.Rounded.Settings, "Settings") { a.page = "settings" }
                    }
                    1 -> {
                        val fr = remember { FocusRequester() }
                        LaunchedEffect(Unit) { delay(120); try { fr.requestFocus() } catch (e: Exception) {} }
                        Row(
                            Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF0F1830)).border(1.dp, Cyan, RoundedCornerShape(22.dp)).padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Search, null, tint = Mute, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(10.dp))
                            BasicTextField(
                                value = a.q, onValueChange = { a.q = it }, singleLine = true,
                                textStyle = TextStyle(color = Color.White, fontSize = 16.sp), cursorBrush = SolidColor(Cyan),
                                modifier = Modifier.weight(1f).focusRequester(fr),
                                decorationBox = { inner -> Box { if (a.q.isEmpty()) Text("Search songs", color = Mute, fontSize = 16.sp); inner() } }
                            )
                            Box(Modifier.size(32.dp).bounceClick { a.q = ""; a.searching = false }, contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.Close, "Close search", tint = Color.White, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                    else -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        TopIcon(Icons.Rounded.Close, "Cancel selection") { a.sel = emptySet() }
                        Text("${a.sel.size} selected", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Cyan, maxLines = 1,
                            modifier = Modifier.weight(1f).padding(horizontal = 12.dp).clickable { a.sel = a.songs.map { it.id }.toSet() })
                        TopIcon(Icons.Rounded.PlaylistAdd, "Add to playlist") { a.sheet = Sheet.AddTo(a.sel.toList()) }
                        Spacer(Modifier.width(8.dp))
                        TopIcon(Icons.Rounded.Share, "Share") { a.shareMany(a.songs.filter { it.id in a.sel }) }
                        Spacer(Modifier.width(8.dp))
                        TopIcon(Icons.Rounded.Delete, "Delete") { a.deleteSongs(a.songs.filter { it.id in a.sel }) }
                    }
                }
            }
        }
        Tabs(pager, onTab)
    }
}

@Composable
fun Tabs(pager: PagerState, onTab: (Int) -> Unit) {
    val names = listOf("Tracks", "Favourites", "Playlists", "Folders")
    val raw = pager.currentPage + pager.currentPageOffsetFraction
    val pos by animateFloatAsState(raw, animationSpec = spring(dampingRatio = 0.9f, stiffness = 450f), label = "tabpos")
    val cap = RoundedCornerShape(999.dp)
    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp).height(44.dp).clip(cap).background(Cyan.copy(alpha = 0.10f))) {
        val tw = maxWidth / 4
        Box(
            Modifier.offset(x = tw * pos).width(tw).fillMaxHeight().padding(3.dp).clip(cap)
                .background(Cyan.copy(alpha = 0.28f)).border(1.dp, Cyan.copy(alpha = 0.6f), cap)
        )
        Row {
            names.forEachIndexed { i, n ->
                val near = (1f - abs(pos - i)).coerceIn(0f, 1f)
                Box(Modifier.width(tw).fillMaxHeight().bounceClick { onTab(i) }, contentAlignment = Alignment.Center) {
                    Text(n, color = lerp(Cyan.copy(alpha = 0.7f), Color.White, near), fontSize = 13.sp, fontWeight = if (near > 0.5f) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun MainScreen(a: App) {
    val pager = rememberPagerState(pageCount = { 4 })
    val scope = rememberCoroutineScope()
    LaunchedEffect(pager.settledPage) { a.curPage = pager.settledPage; a.stamp = System.currentTimeMillis(); a.animated.clear() }
    Box(Modifier.fillMaxSize()) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            when (page) {
                0 -> TracksPage(a)
                1 -> FavPage(a)
                2 -> PlaylistsPage(a)
                else -> FoldersPage(a)
            }
        }
        Header(a, pager) { i -> scope.launch { pager.animateScrollToPage(i, pageOffsetFraction = 0f, animationSpec = tween(380, easing = FastOutSlowInEasing)) } }
    }
}

@Composable
fun TracksPage(a: App) {
    val list = remember(a.songs, a.sort, a.q, a.counts) { a.tracks() }
    ListBody(a, list, 0, a.sort == 0 && a.q.isBlank(), "No songs found")
}

@Composable
fun FavPage(a: App) {
    val list = remember(a.songs, a.favs, a.q) { a.favSongs() }
    ListBody(a, list, 1, false, "No favourite songs yet")
}

@Composable
fun DetailHead(title: String, onBack: () -> Unit, onPlay: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).bounceClick(onClick = onBack), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.ArrowBackIosNew, "Back", tint = Cyan, modifier = Modifier.size(20.dp)) }
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Chip("Play all", true) { onPlay() }
    }
}

@Composable
fun PlaylistsPage(a: App) {
    AnimatedContent(
        targetState = a.openList, label = "pl",
        transitionSpec = {
            if (targetState != null) (slideInHorizontally { it / 4 } + fadeIn()) togetherWith (slideOutHorizontally { -it / 4 } + fadeOut())
            else (slideInHorizontally { -it / 4 } + fadeIn()) togetherWith (slideOutHorizontally { it / 4 } + fadeOut())
        }
    ) { open ->
        if (open == null) {
            val top = with(LocalDensity.current) { a.hdrH.toDp() }
            LazyColumn(Modifier.fillMaxSize().fadeTop(a.hdrH.toFloat()), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = top + 6.dp, bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Chip("+ New playlist", true) { a.sheet = Sheet.NewPl(emptyList()) } }
                if (a.lists.isEmpty()) item { Text("No playlists yet", color = Mute, fontSize = 14.sp, modifier = Modifier.padding(top = 12.dp)) }
                items(a.lists.keys.toList(), key = { it }) { name ->
                    Row(
                        Modifier.fillMaxWidth().bounceClick { a.openList = name }.clip(R16).background(CardC).border(1.dp, LineC, R16).padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${a.lists[name]?.size ?: 0} songs", fontSize = 12.sp, color = Mute)
                        }
                        Box(Modifier.size(40.dp).bounceClick { a.deletePlaylist(name) }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Delete, "Delete playlist", tint = Cyan) }
                    }
                }
            }
        } else {
            val list = remember(a.songs, a.lists, a.q, open) { a.playlistSongs(open) }
            ListBody(a, list, 2, false, "This playlist is empty", { DetailHead(open, { a.openList = null }, { a.playList(list, 0) }) })
        }
    }
}

@Composable
fun FoldersPage(a: App) {
    AnimatedContent(
        targetState = a.openFolder, label = "fo",
        transitionSpec = {
            if (targetState != null) (slideInHorizontally { it / 4 } + fadeIn()) togetherWith (slideOutHorizontally { -it / 4 } + fadeOut())
            else (slideInHorizontally { -it / 4 } + fadeIn()) togetherWith (slideOutHorizontally { it / 4 } + fadeOut())
        }
    ) { open ->
        if (open == null) {
            val top = with(LocalDensity.current) { a.hdrH.toDp() }
            val fl = remember(a.songs) { a.folders() }
            LazyColumn(Modifier.fillMaxSize().fadeTop(a.hdrH.toFloat()), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = top + 6.dp, bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(fl, key = { it.first }) { (dir, l) ->
                    Row(
                        Modifier.fillMaxWidth().bounceClick { a.openFolder = dir }.clip(R16).background(CardC).border(1.dp, LineC, R16).padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Folder, null, tint = Cyan)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(dir.substringAfterLast('/').ifBlank { "Music" }, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${l.size} songs", fontSize = 12.sp, color = Mute)
                        }
                    }
                }
            }
        } else {
            val list = remember(a.songs, a.q, open) { a.folderSongs(open) }
            ListBody(a, list, 3, false, "No songs here", { DetailHead(open.substringAfterLast('/').ifBlank { "Music" }, { a.openFolder = null }, { a.playList(list, 0) }) })
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ListBody(a: App, list: List<Song>, page: Int, az: Boolean, empty: String, head: (@Composable () -> Unit)? = null) {
    val st = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val top = with(LocalDensity.current) { a.hdrH.toDp() }
    Box(Modifier.fillMaxSize()) {
        if (a.loaded && list.isEmpty() && head == null) {
            Column(Modifier.fillMaxSize().padding(top = top), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(if (!a.granted) "Allow access to your music to see your songs" else empty, color = Mute, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(32.dp))
                if (!a.granted) Chip("Allow access", true) { a.askPerm() }
            }
        } else {
            LazyColumn(
                state = st, modifier = Modifier.fillMaxSize().fadeTop(a.hdrH.toFloat()),
                contentPadding = PaddingValues(start = 16.dp, end = if (az) 34.dp else 16.dp, top = top + 6.dp, bottom = 110.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (head != null) item { head() }
                itemsIndexed(list, key = { _, s -> s.id }) { i, s -> SongRow(a, s, i, list, page, Modifier.animateItemPlacement()) }
            }
            if (az && list.isNotEmpty()) AzIndex(list, st, scope, top, Modifier.align(Alignment.CenterEnd))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongRow(a: App, s: Song, i: Int, list: List<Song>, page: Int, mod: Modifier) {
    val on = a.curId == s.id
    val picked = s.id in a.sel
    val key = "$page:${s.id}"
    val skip = key in a.animated
    val prog = remember { Animatable(if (skip) 1f else 0f) }
    LaunchedEffect(a.ready) {
        if (!skip && a.ready) {
            delay(if (System.currentTimeMillis() - a.stamp < 700) minOf(i, 9) * 40L else 0L)
            prog.animateTo(1f, tween(430, easing = FastOutSlowInEasing))
            a.animated.add(key)
        }
    }
    val rem = s.id in a.removing
    val rx by animateFloatAsState(if (rem) 1f else 0f, tween(340, easing = FastOutLinearInEasing), label = "rm")
    val shift by animateDpAsState(if (picked) 4.dp else 0.dp, spring(dampingRatio = 0.6f, stiffness = 400f), label = "shift")
    val bc by animateColorAsState(if (on) Red else if (picked) Cyan else LineC, tween(250), label = "bc")
    val bgc by animateColorAsState(if (picked) Color(0xFF12305E) else CardC, tween(250), label = "bg")
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val ps by animateFloatAsState(if (pressed) 0.975f else 1f, spring(stiffness = 500f), label = "ps")
    Row(
        mod.fillMaxWidth()
            .graphicsLayer { alpha = prog.value * (1f - rx); translationY = (1f - prog.value) * 90f; translationX = rx * size.width; scaleX = ps; scaleY = ps }
            .offset(x = shift).clip(R16).background(bgc).border(1.dp, bc, R16)
            .combinedClickable(
                interactionSource = src, indication = null,
                onClick = { if (a.sel.isNotEmpty()) a.toggleSel(s.id) else a.playList(list, i) },
                onLongClick = { a.toggleSel(s.id) }
            ).padding(start = 14.dp, top = 9.dp, bottom = 9.dp, end = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AnimatedVisibility(picked, enter = expandHorizontally() + scaleIn(spring(dampingRatio = 0.4f, stiffness = 450f)), exit = shrinkHorizontally() + scaleOut()) {
            Box(Modifier.padding(end = 12.dp).size(24.dp).clip(CircleShape).background(Cyan), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Check, null, tint = Dark, modifier = Modifier.size(16.dp))
            }
        }
        Column(Modifier.weight(1f)) {
            Text(s.title, fontSize = 15.sp, color = if (on) Cyan else Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(s.artist + " - " + s.album, fontSize = 12.sp, color = Mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (a.sort == 2 && page == 0) {
            Text("${a.counts[s.id] ?: 0}", fontSize = 12.sp, color = Cyan, modifier = Modifier.padding(horizontal = 6.dp))
        }
        Box(Modifier.size(40.dp).bounceClick { a.sheet = Sheet.Menu(s) }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MoreVert, "More options", tint = Cyan) }
    }
}

@Composable
fun AzIndex(list: List<Song>, st: LazyListState, scope: CoroutineScope, top: Dp, mod: Modifier) {
    val letters = ('A'..'Z').toList() + '#'
    var h by remember { mutableIntStateOf(1) }
    var active by remember { mutableStateOf(false) }
    var idx by remember { mutableIntStateOf(0) }
    var ty by remember { mutableFloatStateOf(0f) }
    fun jump(y: Float) {
        ty = y.coerceIn(0f, h.toFloat())
        val i = ((y / h) * letters.size).toInt().coerceIn(0, letters.size - 1)
        idx = i
        val l = letters[i]
        val at = if (l == '#') 0 else list.indexOfFirst { (it.title.firstOrNull()?.uppercaseChar() ?: '#') >= l }
        if (at >= 0) scope.launch { st.scrollToItem(at) }
    }
    val bubY by animateFloatAsState(ty, animationSpec = spring(dampingRatio = 0.8f, stiffness = 900f), label = "bubY")
    val sc by animateFloatAsState(if (active) 1f else 0f, animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f), label = "bubS")
    Box(mod.fillMaxHeight().width(96.dp).padding(top = top + 8.dp, bottom = 110.dp)) {
        Box(
            Modifier.align(Alignment.TopEnd)
                .offset { IntOffset(-(40.dp.roundToPx()), (bubY - 28.dp.toPx()).toInt()) }
                .graphicsLayer { scaleX = sc; scaleY = sc; alpha = sc.coerceIn(0f, 1f) }
                .size(56.dp).clip(CircleShape).background(Cyan),
            contentAlignment = Alignment.Center
        ) { Text(letters[idx].toString(), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Dark) }
        Column(
            Modifier.align(Alignment.TopEnd).width(30.dp).fillMaxHeight().onSizeChanged { h = it.height.coerceAtLeast(1) }
                .pointerInput(list) {
                    awaitEachGesture {
                        val d = awaitFirstDown()
                        active = true
                        jump(d.position.y)
                        d.consume()
                        do {
                            val e = awaitPointerEvent()
                            val c = e.changes.firstOrNull()
                            if (c != null) { jump(c.position.y); c.consume() }
                        } while (e.changes.any { it.pressed })
                        active = false
                    }
                },
            verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally
        ) { letters.forEachIndexed { i, c -> Text(c.toString(), fontSize = 10.sp, color = if (active && i == idx) Cyan else Mute) } }
    }
}

@Composable
fun MiniBar(a: App, mod: Modifier) {
    val ox = remember { Animatable(0f) }
    var w by remember { mutableIntStateOf(1) }
    val p = if (a.dur > 0) (a.pos.toFloat() / a.dur).coerceIn(0f, 1f) else 0f
    val prog by animateFloatAsState(p, animationSpec = tween(280, easing = LinearEasing), label = "mp")
    val ic by animateColorAsState(a.iconColor, animationSpec = tween(500), label = "mic")
    val vState = rememberDraggableState { d -> a.scope.launch { a.exp.snapTo((a.exp.value - d / (a.hPx * 0.75f)).coerceIn(0f, 1f)) } }
    val hState = rememberDraggableState { d -> a.scope.launch { ox.snapTo(ox.value + d) } }
    Row(
        mod.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp).height(58.dp)
            .onSizeChanged { w = it.width.coerceAtLeast(1) }
            .graphicsLayer {
                translationY = -a.exp.value * 60f
                alpha = (1f - a.exp.value * 1.8f).coerceIn(0f, 1f)
            }
            .clip(RoundedCornerShape(22.dp)).background(Color(0xFF111A30)).border(1.dp, LineC, RoundedCornerShape(22.dp))
            .draggable(vState, Orientation.Vertical, onDragStopped = { v ->
                a.scope.launch { a.exp.animateTo(if (v < -700f || (v < 700f && a.exp.value > 0.4f)) 1f else 0f, spring(dampingRatio = 0.9f, stiffness = 260f)) }
            })
            .draggable(hState, Orientation.Horizontal, onDragStopped = { v ->
                a.scope.launch {
                    val dir = if (ox.value < -w * 0.22f || v < -1300f) -1 else if (ox.value > w * 0.22f || v > 1300f) 1 else 0
                    if (dir == 0) ox.animateTo(0f, spring(dampingRatio = 0.7f, stiffness = 400f)) else {
                        ox.animateTo(dir * w * 0.7f, tween(150))
                        if (dir < 0) a.ctl?.seekToNextMediaItem() else a.ctl?.seekToPreviousMediaItem()
                        a.ctl?.play()
                        ox.snapTo(-dir * w * 0.5f)
                        ox.animateTo(0f, spring(dampingRatio = 0.8f, stiffness = 350f))
                    }
                }
            })
            .clickable { a.expand() }.padding(start = 9.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(ic, lerp(ic, Color.Black, 0.35f)))), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.MusicNote, null, tint = if (ic.luminance() > 0.35f) Color(0xFF021022) else Color.White, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(
            Modifier.weight(1f).graphicsLayer {
                translationX = ox.value
                alpha = (1f - abs(ox.value) / w * 1.4f).coerceIn(0f, 1f)
            }
        ) {
            Marquee(a.title, ic, 14.sp, a.playing, Modifier.fillMaxWidth())
            Text(a.artist, fontSize = 11.sp, color = Mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 2.5.dp.toPx()
                drawArc(Color(0xFF16213D), -90f, 360f, false, style = Stroke(sw))
                drawArc(Cyan, -90f, 360f * prog, false, style = Stroke(sw, cap = StrokeCap.Round))
            }
            PlayBtn(a, 30.dp, 18.dp)
        }
    }
}
