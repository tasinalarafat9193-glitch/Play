package com.play.music

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

@Composable
fun PlayBtn(a: App, size: Dp, iconSize: Dp) {
    val col by animateColorAsState(if (a.playing) Theme.accent2 else Theme.accent, tween(380), label = "pc")
    val t by animateFloatAsState(if (a.playing) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 300f), label = "pt")
    val ic = if (col.luminance() > 0.35f) Color(0xFF021022) else Color.White
    Box(
        Modifier.size(size).bounceClick { if (a.playing) a.ctl?.pause() else a.ctl?.play() }.clip(CircleShape)
            .background(Brush.linearGradient(listOf(lerp(col, Color.White, 0.4f), col, lerp(col, Color.Black, 0.3f)))),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.PlayArrow, "Play", tint = ic, modifier = Modifier.size(iconSize).graphicsLayer {
            alpha = (1f - t).coerceIn(0f, 1f); scaleX = 1f - 0.6f * t; scaleY = 1f - 0.6f * t; rotationZ = 90f * t
        })
        Icon(Icons.Rounded.Pause, "Pause", tint = ic, modifier = Modifier.size(iconSize).graphicsLayer {
            alpha = t.coerceIn(0f, 1f); scaleX = 0.4f + 0.6f * t; scaleY = 0.4f + 0.6f * t; rotationZ = -90f * (1f - t)
        })
    }
}

@Composable
fun CtlBtn(size: Dp, round: Boolean, border: Color, onClick: () -> Unit, bg: Color = Color(0xFF101A33), content: @Composable () -> Unit) {
    val sh = if (round) CircleShape else RoundedCornerShape(16.dp)
    val bc by animateColorAsState(border, tween(250), label = "cb")
    Box(Modifier.size(size).bounceClick(onClick = onClick).clip(sh).background(bg).border(1.5.dp, bc, sh), contentAlignment = Alignment.Center) { content() }
}

@Composable
fun HeartBtn(on: Boolean, onClick: () -> Unit) {
    val col by animateColorAsState(if (on) Theme.accent2 else Mute, tween(300), label = "hc")
    val sc = remember { Animatable(1f) }
    val burst = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    Box(
        Modifier.size(52.dp).bounceClick {
            onClick()
            if (!on) scope.launch {
                launch { sc.snapTo(0.55f); sc.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 380f)) }
                burst.snapTo(0f); burst.animateTo(1f, tween(560))
            }
        },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val b = burst.value
            if (b < 1f) for (k in 0 until 8) {
                val ang = k * 0.7853982f
                val r = 16.dp.toPx() + 14.dp.toPx() * b
                drawCircle(Theme.accent2.copy(alpha = 1f - b), 3.dp.toPx() * (1f - b) + 0.5f, center + Offset(cos(ang) * r, sin(ang) * r))
            }
        }
        Icon(if (on) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favourite", tint = col,
            modifier = Modifier.size(30.dp).graphicsLayer { scaleX = sc.value; scaleY = sc.value })
    }
}

@Composable
fun SeekBar(a: App, mod: Modifier) {
    var held by remember { mutableStateOf(false) }
    var w by remember { mutableIntStateOf(1) }
    val p = if (a.dur > 0) (a.pos.toFloat() / a.dur).coerceIn(0f, 1f) else 0f
    val shown by animateFloatAsState(p, if (held) snap() else tween(280, easing = LinearEasing), label = "sk")
    val sc by animateFloatAsState(if (held) 1.8f else 1f, spring(dampingRatio = 0.5f, stiffness = 400f), label = "sks")
    val inf = rememberInfiniteTransition(label = "thumb")
    val ph by inf.animateFloat(initialValue = 0f, targetValue = 10f, animationSpec = infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "ph")
    Box(
        mod.fillMaxWidth().height(40.dp).onSizeChanged { w = it.width.coerceAtLeast(1) }.pointerInput(Unit) {
            awaitEachGesture {
                val d = awaitFirstDown()
                held = true
                a.drag = true
                a.pos = (d.position.x / w * a.dur).toLong().coerceIn(0L, a.dur)
                do {
                    val e = awaitPointerEvent()
                    val c = e.changes.firstOrNull()
                    if (c != null) { a.pos = (c.position.x / w * a.dur).toLong().coerceIn(0L, a.dur); c.consume() }
                } while (e.changes.any { it.pressed })
                a.ctl?.seekTo(a.pos)
                held = false
                a.drag = false
            }
        }
    ) {
        Canvas(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            val cy = size.height / 2
            val th = 6.dp.toPx()
            val i = ph.toInt().coerceIn(0, 9)
            val tc = lerp(Pal10[i], Pal10[(i + 1) % 10], ph - i)
            drawRoundRect(Color(0xFF16213D), Offset(0f, cy - th / 2), Size(size.width, th), CornerRadius(th / 2))
            val x = size.width * shown
            if (x > 1f) drawRoundRect(Brush.horizontalGradient(listOf(Theme.accent, Theme.accent2), 0f, size.width), Offset(0f, cy - th / 2), Size(x, th), CornerRadius(th / 2))
            drawCircle(Color.White, 8.dp.toPx() * sc, Offset(x, cy))
            drawCircle(tc, 8.dp.toPx() * sc, Offset(x, cy), style = Stroke(3.5.dp.toPx()))
        }
    }
}

@Composable
fun VinylVisual(a: App) {
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(a.playing) {
        var last = 0L
        while (a.playing) {
            withFrameNanos { t ->
                if (last != 0L) angle = (angle + (t - last) / 1e9f * 40f) % 360f
                last = t
            }
        }
    }
    val arm by animateFloatAsState(if (a.playing) 1f else 0f, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessVeryLow), label = "arm")
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val d = (if (maxWidth < maxHeight) maxWidth else maxHeight) - 44.dp
        val dd = if (d < 110.dp) 110.dp else d
        Box(
            Modifier.size(dd).graphicsLayer { rotationZ = angle }.clip(CircleShape)
                .background(Brush.sweepGradient(listOf(Color(0xFF0A0F1D), Color(0xFF123A8F), Color(0xFF0A0F1D), Color(0xFF0AB8D1), Color(0xFF0A0F1D), Color(0xFF7A1230), Color(0xFF0A0F1D))))
                .border(3.dp, Cyan, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.fillMaxSize(0.35f).clip(CircleShape).background(Red), contentAlignment = Alignment.Center) { Box(Modifier.size(10.dp).clip(CircleShape).background(Bg)) }
        }
        Canvas(Modifier.fillMaxSize()) {
            val pivot = Offset(size.width - 26.dp.toPx(), 22.dp.toPx())
            val c = Offset(size.width / 2, size.height / 2)
            val r = dd.toPx() / 2
            val dx = pivot.x - c.x
            val dy = c.y - pivot.y
            val on = Math.toDegrees(atan2(dx, dy).toDouble()).toFloat()
            val len = hypot(dx, dy) - r * 0.55f
            rotate(on - 38f * (1f - arm), pivot) {
                drawLine(Color(0xFFB8C4E0), pivot, Offset(pivot.x, pivot.y + len), 5.dp.toPx(), StrokeCap.Round)
                drawCircle(Theme.accent, 7.dp.toPx(), Offset(pivot.x, pivot.y + len))
            }
            drawCircle(Color(0xFF2A3558), 12.dp.toPx(), pivot)
            drawCircle(Theme.accent, 5.dp.toPx(), pivot)
        }
    }
}

@Composable
fun BarsVisual(a: App) {
    val tr = rememberInfiniteTransition(label = "bars")
    val t by tr.animateFloat(initialValue = 0f, targetValue = 6.2831855f, animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "bt")
    val amp by animateFloatAsState(if (a.playing) 1f else 0.12f, tween(700), label = "amp")
    Canvas(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 26.dp)) {
        val n = 28
        val gap = 5.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val v = (0.5f + 0.5f * sin(t + i * 0.45f)) * 0.6f + (0.5f + 0.5f * sin(2f * t + i * 0.9f)) * 0.4f
            val h = size.height * (0.1f + 0.9f * v * amp)
            drawRoundRect(lerp(Theme.accent, Theme.accent2, i / (n - 1f)), Offset(i * (bw + gap), size.height - h), Size(bw, h), CornerRadius(bw / 2))
        }
    }
}

@Composable
fun FullPlayer(a: App) {
    var tabC by remember { mutableIntStateOf(0) }
    val cur = a.curId?.let { a.byId[it] }
    val fav = a.curId?.let { it in a.favs } ?: false
    val ix by animateFloatAsState(tabC.toFloat(), spring(dampingRatio = 0.8f, stiffness = 350f), label = "tabix")
    val vState = rememberDraggableState { d -> a.scope.launch { a.exp.snapTo((a.exp.value - d / (a.hPx * 0.75f)).coerceIn(0f, 1f)) } }
    Column(
        Modifier.fillMaxSize()
            .graphicsLayer { translationY = (1f - a.exp.value) * a.hPx; alpha = (a.exp.value * 4f).coerceIn(0f, 1f) }
            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
            .background(bgBrush())
            .draggable(vState, Orientation.Vertical, onDragStopped = { v ->
                a.scope.launch { a.exp.animateTo(if (v > 700f || (v > -700f && a.exp.value < 0.6f)) 0f else 1f, spring(dampingRatio = 0.9f, stiffness = 260f)) }
            })
            .pointerInput(Unit) { detectTapGestures { } },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.padding(top = 10.dp).width(44.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Mute.copy(alpha = 0.5f)))
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Spacer(Modifier.size(38.dp))
            Box(Modifier.width(184.dp).clip(RoundedCornerShape(999.dp)).background(CardC).border(1.dp, LineC, RoundedCornerShape(999.dp)).padding(4.dp)) {
                Box(Modifier.offset(x = 90.dp * ix).width(90.dp).height(34.dp).clip(RoundedCornerShape(999.dp)).background(Cyan.copy(alpha = 0.25f)))
                Row {
                    listOf("COVER", "LYRIC").forEachIndexed { i, t ->
                        Text(t, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (tabC == i) Color.White else Cyan.copy(alpha = 0.7f), maxLines = 1,
                            modifier = Modifier.width(90.dp).height(34.dp).bounceClick { tabC = i }.wrapContentHeight(Alignment.CenterVertically),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
            TopIcon(Icons.Rounded.MoreVert, "More options") { cur?.let { a.sheet = Sheet.Menu(it, true) } }
        }
        Box(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 38.dp, vertical = 12.dp).clip(R28).background(CardC).border(1.dp, LineC, R28)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                    if (tabC == 0) { a.visual = 1 - a.visual; a.store.visual = a.visual }
                },
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = if (tabC == 1) 2 else a.visual, animationSpec = tween(380), label = "vis") { m ->
                when (m) {
                    0 -> VinylVisual(a)
                    1 -> BarsVisual(a)
                    else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Lyrics aren’t available for this song yet.", color = Mute, fontSize = 15.sp, modifier = Modifier.padding(24.dp)) }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 26.dp, end = 14.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Marquee(a.title, Color.White, 24.sp, a.playing, Modifier.fillMaxWidth(), FontWeight.ExtraBold)
                Text(a.artist, fontSize = 15.sp, color = Mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            HeartBtn(fav) { a.curId?.let { a.toggleFav(it) } }
        }
        SeekBar(a, Modifier.padding(horizontal = 14.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 26.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(a.pos), color = Mute, fontSize = 12.sp)
            Text(fmt(a.dur), color = Mute, fontSize = 12.sp)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            CtlBtn(46.dp, false, if (a.shuffle) Cyan else Cyan.copy(alpha = 0.35f), {
                val n = !a.shuffle
                a.ctl?.setShuffleModeEnabled(n)
                a.store.shuf = n
            }, if (a.shuffle) Cyan.copy(alpha = 0.22f) else Color(0xFF101A33)) { Icon(Icons.Rounded.Shuffle, "Shuffle", tint = Cyan) }
            CtlBtn(58.dp, true, Cyan, { a.ctl?.seekToPrevious(); a.ctl?.play() }) { Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Cyan, modifier = Modifier.size(30.dp)) }
            PlayBtn(a, 82.dp, 42.dp)
            CtlBtn(58.dp, true, Cyan, { a.ctl?.seekToNext(); a.ctl?.play() }) { Icon(Icons.Rounded.SkipNext, "Next", tint = Cyan, modifier = Modifier.size(30.dp)) }
            CtlBtn(46.dp, false, if (a.rep != 0) Cyan else Cyan.copy(alpha = 0.35f), {
                val n = when (a.rep) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }
                a.ctl?.setRepeatMode(n)
                a.store.rpt = n
            }, if (a.rep != 0) Cyan.copy(alpha = 0.22f) else Color(0xFF101A33)) { Icon(if (a.rep == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, "Repeat", tint = Cyan) }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 22.dp), horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
            Row(
                Modifier.bounceClick { a.sheet = Sheet.SpeedS }.clip(RoundedCornerShape(999.dp)).background(Color(0xFF101A33)).border(1.dp, LineC, RoundedCornerShape(999.dp)).padding(horizontal = 14.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Speed, "Speed", tint = Cyan, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text("%.2fx".format(a.speed).replace(".00x", ".0x"), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Cyan)
            }
            CtlBtn(40.dp, true, Cyan.copy(alpha = 0.5f), { a.sheet = Sheet.QueueL }) { Icon(Icons.Rounded.QueueMusic, "Queue", tint = Cyan, modifier = Modifier.size(22.dp)) }
        }
    }
}
