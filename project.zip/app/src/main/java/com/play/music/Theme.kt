package com.play.music

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.dp

object Theme {
    var accent by mutableStateOf(Color(0xFF22E6FF))
    var accent2 by mutableStateOf(Color(0xFFFF2D55))
    var tint by mutableStateOf(Color(0xFF0B1C4D))
    var gradient by mutableStateOf(true)
    val deep: Color get() = lerp(accent, Color.Black, 0.45f)
    val onAccent: Color get() = if (accent.luminance() > 0.35f) Color(0xFF021022) else Color.White
}

val Cyan: Color get() = Theme.accent
val Red: Color get() = Theme.accent2
val Blue: Color get() = Theme.deep
val Dark: Color get() = Theme.onAccent
val Bg = Color(0xFF04060C)
val CardC = Color(0xFF0C1220)
val LineC = Color(0xFF1A2540)
val Mute = Color(0xFF8592B0)
val SheetC = Color(0xFF14171F)
val R16 = RoundedCornerShape(16.dp)
val R28 = RoundedCornerShape(28.dp)

fun bgBrush(): Brush = if (Theme.gradient) Brush.verticalGradient(listOf(Theme.tint, Bg), endY = 1600f) else SolidColor(Bg)

fun Modifier.bounceClick(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.86f else 1f, animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f), label = "bounce")
    this.graphicsLayer { scaleX = s; scaleY = s }.clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

fun Modifier.fadeTop(h: Float): Modifier = this
    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
    .drawWithContent {
        drawContent()
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black), startY = h * 0.45f, endY = h.coerceAtLeast(2f)), blendMode = BlendMode.DstIn)
    }
