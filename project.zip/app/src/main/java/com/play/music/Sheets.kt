package com.play.music

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun MI(icon: ImageVector, text: String, tint: Color = Color.White, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().bounceClick(onClick = onClick).padding(horizontal = 24.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(18.dp))
        Text(text, fontSize = 17.sp, color = tint, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun SheetTitle(t: String) {
    Text(t, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SheetHost(a: App) {
    val sh = a.sheet
    if (sh is Sheet.NewPl) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { a.sheet = null }, containerColor = SheetC, titleContentColor = Color.White, textContentColor = Color.White,
            title = { Text("New playlist") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, placeholder = { Text("Playlist name", color = Mute) }) },
            confirmButton = {
                TextButton(onClick = {
                    val n = name.trim()
                    if (n.isNotEmpty()) { a.addToPlaylist(n, sh.ids); a.sheet = null; a.sel = emptySet() }
                }) { Text("Create", color = Cyan) }
            },
            dismissButton = { TextButton(onClick = { a.sheet = null }) { Text("Cancel", color = Mute) } }
        )
    } else if (sh != null) {
        ModalBottomSheet(onDismissRequest = { a.sheet = null }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = SheetC, contentColor = Color.White) {
            AnimatedContent(targetState = sh, transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(120)) }, label = "sheet") { s ->
                when (s) {
                    is Sheet.Menu -> MenuSheet(a, s.s)
                    is Sheet.SortBy -> SortSheet(a)
                    is Sheet.SleepT -> SleepSheet(a)
                    is Sheet.Equal -> EqSheet(a)
                    is Sheet.QueueL -> QueueSheet(a)
                    is Sheet.Tools -> ToolsSheet(a)
                    is Sheet.Look -> LookSheet(a)
                    is Sheet.WidgetS -> WidgetSheet(a)
                    is Sheet.SpeedS -> SpeedSheet(a)
                    is Sheet.AddTo -> AddToSheet(a, s.ids)
                    is Sheet.NewPl -> {}
                }
            }
        }
    }
    a.info?.let { s ->
        AlertDialog(
            onDismissRequest = { a.info = null }, containerColor = SheetC, titleContentColor = Color.White, textContentColor = Color.White,
            title = { Text("Song info") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Title" to s.title, "Artist" to s.artist, "Album" to s.album, "Duration" to fmt(s.dur), "Size" to "%.1f MB".format(s.size / 1048576.0), "File" to s.file, "Path" to s.path).forEach { (k, v) ->
                        Column { Text(k, fontSize = 12.sp, color = Mute); Text(v, fontSize = 14.sp) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { a.info = null }) { Text("Close", color = Cyan) } }
        )
    }
    if (a.about) {
        val ver = try { a.ctx.packageManager.getPackageInfo(a.ctx.packageName, 0).versionName } catch (e: Exception) { "2.0" }
        AlertDialog(
            onDismissRequest = { a.about = false }, containerColor = SheetC, titleContentColor = Color.White, textContentColor = Color.White,
            title = {
                Row {
                    Text("Play", color = Cyan, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                    Text(".", color = Red, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Version $ver", fontSize = 15.sp)
                    Text("Creator: Tasin Al Arafat", fontSize = 15.sp, color = Mute)
                }
            },
            confirmButton = { TextButton(onClick = { a.about = false }) { Text("Close", color = Cyan) } }
        )
    }
}

@Composable
fun MenuSheet(a: App, s: Song) {
    val isFav = s.id in a.favs
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Text("Cancel", color = Red, fontSize = 17.sp, modifier = Modifier.bounceClick { a.sheet = null }.padding(horizontal = 24.dp, vertical = 10.dp))
        MI(Icons.Rounded.SkipNext, "Play next") { a.sheet = null; a.playNext(s) }
        MI(Icons.Rounded.QueueMusic, "Add to play queue") { a.sheet = null; a.addQueue(s) }
        MI(Icons.Rounded.PlaylistAdd, "Add to Playlist") { a.sheet = Sheet.AddTo(listOf(s.id)) }
        MI(if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, if (isFav) "Remove from favorites" else "Add to favorites", Red) { a.sheet = null; a.toggleFav(s.id) }
        MI(Icons.Rounded.Album, "Album: " + s.album) { a.sheet = null; a.q = s.album; a.searching = true }
        MI(Icons.Rounded.Info, "Song Info") { a.sheet = null; a.info = s }
        MI(Icons.Rounded.NotificationsActive, "Set Ringtone") { a.sheet = null; a.ringtone(s) }
        MI(Icons.Rounded.Share, "Share local file") { a.sheet = null; a.share(s) }
        MI(Icons.Rounded.Delete, "Delete") { a.sheet = null; a.deleteSongs(listOf(s)) }
    }
}

@Composable
fun SortSheet(a: App) {
    Column(Modifier.padding(bottom = 24.dp)) {
        SheetTitle("Sort order")
        listOf("Sort by song title", "Sort by date added", "Sort by play count").forEachIndexed { i, n ->
            MI(if (a.sort == i) Icons.Rounded.Check else Icons.Rounded.Sort, n, if (a.sort == i) Cyan else Color.White) { a.sort = i; a.store.sort = i; a.sheet = null }
        }
    }
}

@Composable
fun SleepSheet(a: App) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(40) } }
    Column(Modifier.fillMaxWidth().padding(bottom = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        SheetTitle("Sleep timer")
        if (Sleep.endAt > 0) {
            val left = (Sleep.endAt - now).coerceAtLeast(0L)
            val frac = (left.toFloat() / Sleep.total).coerceIn(0f, 1f)
            Box(Modifier.size(190.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize().padding(10.dp)) {
                    val sw = 10.dp.toPx()
                    drawArc(Color(0xFF16213D), -90f, 360f, false, style = Stroke(sw))
                    drawArc(Brush.sweepGradient(listOf(Theme.accent, Theme.accent2, Theme.accent)), -90f, 360f * frac, false, style = Stroke(sw, cap = StrokeCap.Round))
                }
                Text(fmt(left), fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Chip("Turn off timer", true) { Sleep.cancel(); a.sheet = null }
        } else {
            Column(Modifier.fillMaxWidth()) {
                listOf(15, 30, 45, 60).forEach { m -> MI(Icons.Rounded.Bedtime, "$m minutes") { Sleep.start(m); a.sheet = null; a.toast("Music will stop in $m minutes") } }
            }
        }
    }
}

@Composable
fun EqSheet(a: App) {
    val eq = PlayerService.eq
    val bass = PlayerService.bass
    val scope = rememberCoroutineScope()
    Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 24.dp).padding(bottom = 28.dp)) {
        Text("Equalizer", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        if (eq == null) {
            Spacer(Modifier.height(12.dp))
            Text("The equalizer isn’t ready yet. Play a song first, then open this again.", color = Mute)
        } else {
            val n = eq.numberOfBands.toInt()
            val lo = eq.bandLevelRange[0].toFloat()
            val hi = eq.bandLevelRange[1].toFloat()
            val lv = remember { mutableStateListOf<Int>().also { l -> for (i in 0 until n) l.add(eq.getBandLevel(i.toShort()).toInt()) } }
            var on by remember { mutableStateOf(eq.getEnabled()) }
            var bs by remember { mutableFloatStateOf(a.store.bass.toFloat()) }
            fun glide(to: List<Int>) {
                val from = lv.toList()
                scope.launch {
                    for (s in 1..16) {
                        delay(16)
                        val f = FastOutSlowInEasing.transform(s / 16f)
                        for (i in 0 until n) lv[i] = (from[i] + (to[i] - from[i]) * f).toInt()
                    }
                    a.store.saveEq(lv.toList(), on)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Enabled", modifier = Modifier.weight(1f))
                Switch(checked = on, onCheckedChange = { on = it; eq.setEnabled(it); a.store.saveEq(lv.toList(), it) }, colors = SwitchDefaults.colors(checkedTrackColor = Cyan, checkedThumbColor = Dark))
            }
            val np = eq.numberOfPresets.toInt()
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Flat", false) {
                    for (i in 0 until n) eq.setBandLevel(i.toShort(), 0.toShort())
                    glide(List(n) { 0 })
                }
                for (p in 0 until np) {
                    Chip(eq.getPresetName(p.toShort()), false) {
                        eq.usePreset(p.toShort())
                        glide(List(n) { eq.getBandLevel(it.toShort()).toInt() })
                    }
                }
            }
            Text("Bass boost", color = Mute, fontSize = 13.sp)
            if (bass == null) Text("Bass boost isn’t supported on this phone.", color = Mute, fontSize = 13.sp) else Slider(
                value = bs, onValueChange = { bs = it; bass.setStrength(it.toInt().toShort()) }, onValueChangeFinished = { a.store.bass = bs.toInt() },
                valueRange = 0f..1000f, colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Red, inactiveTrackColor = Color(0xFF16213D))
            )
            for (i in 0 until n) {
                Text(hz(eq.getCenterFreq(i.toShort())), color = Mute, fontSize = 13.sp)
                Slider(
                    value = lv[i].toFloat().coerceIn(lo, hi),
                    onValueChange = { v -> lv[i] = v.toInt(); eq.setBandLevel(i.toShort(), v.toInt().toShort()) },
                    onValueChangeFinished = { a.store.saveEq(lv.toList(), on) },
                    valueRange = lo..hi,
                    colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF16213D))
                )
            }
        }
    }
}

@Composable
fun QueueSheet(a: App) {
    Column(Modifier.padding(bottom = 16.dp)) {
        SheetTitle("Queue (${a.queue.size})")
        LazyColumn(Modifier.heightIn(max = 460.dp)) {
            itemsIndexed(a.queue) { i, m ->
                val on = m.mediaId == a.curId?.toString()
                Row(Modifier.fillMaxWidth().bounceClick { a.ctl?.seekTo(i, 0L); a.ctl?.play() }.padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}", color = if (on) Red else Mute, modifier = Modifier.width(36.dp))
                    Column {
                        Text(m.mediaMetadata.title?.toString() ?: "", color = if (on) Cyan else Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(m.mediaMetadata.artist?.toString() ?: "", color = Mute, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun AddToSheet(a: App, ids: List<Long>) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        SheetTitle("Add to playlist")
        MI(Icons.Rounded.Add, "New playlist", Cyan) { a.sheet = Sheet.NewPl(ids) }
        a.lists.keys.toList().forEach { name ->
            MI(Icons.Rounded.QueueMusic, name) { a.addToPlaylist(name, ids); a.sheet = null; a.sel = emptySet(); a.toast("Added to $name") }
        }
    }
}

@Composable
fun SpeedSheet(a: App) {
    Column(Modifier.padding(bottom = 24.dp)) {
        SheetTitle("Playback speed")
        listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
            val on = kotlin.math.abs(a.speed - s) < 0.01f
            MI(if (on) Icons.Rounded.Check else Icons.Rounded.Speed, (if (s == 1f) "Normal (1.0x)" else "${s}x"), if (on) Cyan else Color.White) { a.changeSpeed(s); a.sheet = null }
        }
    }
}

@Composable
fun ToolsSheet(a: App) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        SheetTitle("Tools")
        MI(Icons.Rounded.Bedtime, "Sleep timer") { a.sheet = Sheet.SleepT }
        MI(Icons.Rounded.GraphicEq, "Equalizer") { a.sheet = Sheet.Equal }
        MI(Icons.Rounded.Palette, "Appearance") { a.sheet = Sheet.Look }
        MI(Icons.Rounded.Widgets, "Home Screen Widget") { a.sheet = Sheet.WidgetS }
        Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 6.dp).height(1.dp).background(LineC))
        MI(Icons.Rounded.Info, "About Play") { a.sheet = null; a.about = true }
    }
}

class Preset(val name: String, val a: Long, val b: Long, val t: Long)

val presets = listOf(
    Preset("Cyan Night", 0xFF22E6FF, 0xFFFF2D55, 0xFF0B1C4D),
    Preset("Ocean", 0xFF4DA3FF, 0xFF00E5C3, 0xFF0A2A5C),
    Preset("Sunset", 0xFFFF8A3D, 0xFFFF3D81, 0xFF4A1530),
    Preset("Violet", 0xFFB388FF, 0xFFFF6EC7, 0xFF2A1459),
    Preset("Emerald", 0xFF2CFF9A, 0xFFFFD93D, 0xFF0B3B2C),
    Preset("Rose", 0xFFFF5C8A, 0xFFFFB36B, 0xFF4A1022),
    Preset("Gold", 0xFFFFC93C, 0xFFFF5C5C, 0xFF3A2A08),
    Preset("Mono", 0xFFE8E8E8, 0xFF8AB4FF, 0xFF1C1C1C)
)

val swatches = listOf(
    0xFF22E6FF, 0xFF4DA3FF, 0xFF2563FF, 0xFFB388FF, 0xFFFF6EC7, 0xFFFF2D55, 0xFFFF8A3D,
    0xFFFFC93C, 0xFF2CFF9A, 0xFF00E5C3, 0xFFFFFFFF, 0xFFB0B8C8, 0xFFFF5C8A, 0xFF9CFF3D
)

val tints = listOf(0xFF0B1C4D, 0xFF2A1459, 0xFF4A1530, 0xFF0B3B2C, 0xFF4A1022, 0xFF3A2A08, 0xFF1C1C1C, 0xFF04060C)

@Composable
fun Swatch(c: Long, selected: Boolean, onClick: () -> Unit) {
    val bc by androidx.compose.animation.animateColorAsState(if (selected) Color.White else Color.Transparent, tween(200), label = "sw")
    Box(Modifier.size(34.dp).bounceClick(onClick = onClick).clip(CircleShape).background(Color(c)).border(2.dp, bc, CircleShape))
}

@Composable
fun LookSheet(a: App) {
    val hsv = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(Theme.accent.toArgb(), it) } }
    var h by remember { mutableFloatStateOf(hsv[0]) }
    var s by remember { mutableFloatStateOf(hsv[1]) }
    var v by remember { mutableFloatStateOf(hsv[2]) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
        Text("Appearance", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Themes", color = Mute, fontSize = 13.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            presets.forEach { p ->
                val on = Theme.accent == Color(p.a) && Theme.accent2 == Color(p.b)
                Column(Modifier.bounceClick {
                    Theme.accent = Color(p.a); Theme.accent2 = Color(p.b); Theme.tint = Color(p.t); a.saveTheme()
                }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(56.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(p.a), Color(p.b)))).border(2.dp, if (on) Color.White else LineC, CircleShape))
                    Text(p.name, fontSize = 11.sp, color = if (on) Color.White else Mute, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Gradient background", modifier = Modifier.weight(1f))
            Switch(checked = Theme.gradient, onCheckedChange = { Theme.gradient = it; a.saveTheme() }, colors = SwitchDefaults.colors(checkedTrackColor = Cyan, checkedThumbColor = Dark))
        }
        Spacer(Modifier.height(14.dp))
        Text("Background tint", color = Mute, fontSize = 13.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            tints.forEach { c -> Swatch(c, Theme.tint == Color(c)) { Theme.tint = Color(c); a.saveTheme() } }
        }
        Text("Accent colour", color = Mute, fontSize = 13.sp)
        swatches.chunked(7).forEach { row ->
            Row(Modifier.padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { c -> Swatch(c, Theme.accent == Color(c)) { Theme.accent = Color(c); a.saveTheme() } }
            }
        }
        Text("Custom colour", color = Mute, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        val cs = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF16213D))
        Text("Hue", fontSize = 12.sp)
        Slider(h, { h = it; Theme.accent = Color.hsv(h, s, v) }, valueRange = 0f..360f, onValueChangeFinished = { a.saveTheme() }, colors = cs)
        Text("Saturation", fontSize = 12.sp)
        Slider(s, { s = it; Theme.accent = Color.hsv(h, s, v) }, valueRange = 0f..1f, onValueChangeFinished = { a.saveTheme() }, colors = cs)
        Text("Brightness", fontSize = 12.sp)
        Slider(v, { v = it; Theme.accent = Color.hsv(h, s, v) }, valueRange = 0.3f..1f, onValueChangeFinished = { a.saveTheme() }, colors = cs)
        Text("Highlight colour", color = Mute, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        swatches.chunked(7).forEach { row ->
            Row(Modifier.padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { c -> Swatch(c, Theme.accent2 == Color(c)) { Theme.accent2 = Color(c); a.saveTheme() } }
            }
        }
    }
}

@Composable
fun WidgetCard(name: String, desc: String, a: App, cls: Class<*>, preview: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(R16).background(CardC).border(1.dp, LineC, R16).padding(14.dp)) {
        preview()
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(desc, fontSize = 12.sp, color = Mute)
            }
            Chip("Add", true) {
                if (!WidgetHelper.pin(a.ctx, cls)) a.toast("Long-press your home screen, tap Widgets, then pick Play")
            }
        }
    }
}

@Composable
fun WidgetSheet(a: App) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Home Screen Widget", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        WidgetCard("Pill", "Slim player bar, 4 x 1", a, PillWidget::class.java) {
            Row(Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp)).background(Color(0xFF0C1220)).border(1.dp, LineC, RoundedCornerShape(26.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2563FF)), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MusicNote, null, tint = Color(0xFF22E6FF), modifier = Modifier.size(20.dp)) }
                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text("Song title", fontSize = 13.sp, maxLines = 1); Text("Artist", fontSize = 11.sp, color = Mute) }
                Icon(Icons.Rounded.SkipPrevious, null, tint = Color(0xFF22E6FF))
                Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF22E6FF)), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.PlayArrow, null, tint = Color(0xFF021022)) }
                Icon(Icons.Rounded.SkipNext, null, tint = Color(0xFF22E6FF))
            }
        }
        WidgetCard("Vinyl", "Square card with a record, 2 x 2", a, VinylWidget::class.java) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.verticalGradient(listOf(Color(0xFF0B1C4D), Color(0xFF04060C)))).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(64.dp).clip(CircleShape).background(Color(0xFF0A1328)).border(2.dp, Color(0xFF22E6FF), CircleShape), contentAlignment = Alignment.Center) { Box(Modifier.size(24.dp).clip(CircleShape).background(Color(0xFFFF2D55))) }
                Text("Song title", fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.SkipPrevious, null, tint = Color(0xFF22E6FF))
                    Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF22E6FF)), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.PlayArrow, null, tint = Color(0xFF021022), modifier = Modifier.size(20.dp)) }
                    Icon(Icons.Rounded.SkipNext, null, tint = Color(0xFF22E6FF))
                }
            }
        }
        WidgetCard("Beats", "Wide card with bars, 4 x 2", a, BarsWidget::class.java) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF123A8F), Color(0xFF04060C)))).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Song title", fontSize = 15.sp); Text("Artist", fontSize = 11.sp, color = Color(0xFFA9B8D8)) }
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom, modifier = Modifier.height(34.dp)) {
                        listOf(14, 24, 34, 20, 12, 28).forEachIndexed { i, hh -> Box(Modifier.width(5.dp).height(hh.dp).clip(RoundedCornerShape(2.dp)).background(if (i % 2 == 0) Color(0xFF22E6FF) else Color(0xFFFF2D55))) }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.SkipPrevious, null, tint = Color(0xFF22E6FF))
                    Box(Modifier.size(38.dp).clip(CircleShape).background(Color(0xFF22E6FF)), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.PlayArrow, null, tint = Color(0xFF021022)) }
                    Icon(Icons.Rounded.SkipNext, null, tint = Color(0xFF22E6FF))
                }
            }
        }
    }
}
