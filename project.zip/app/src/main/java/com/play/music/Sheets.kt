package com.play.music

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val Yellow = Color(0xFFFFD93D)

@Composable
fun MI(icon: ImageVector, text: String, tint: Color = Cyan, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().bounceClick(onClick = onClick).padding(horizontal = 24.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(18.dp))
        Text(text, fontSize = 17.sp, color = tint, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun SheetTitle(t: String) {
    Text(t, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SheetHost(a: App) {
    val sh = a.sheet
    if (sh is Sheet.NewPl) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { a.sheet = null }, containerColor = SheetC, titleContentColor = Color.White, textContentColor = Color.White,
            title = { Text("New playlist") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, placeholder = { Text("Playlist name", color = Mute) }) },
            confirmButton = {
                TextButton(onClick = {
                    val n = name.trim()
                    if (n.isNotEmpty()) { a.addToPlaylist(n, sh.ids); a.sheet = null; a.sel = emptySet() }
                }) { Text("Create", color = Cyan) }
            },
            dismissButton = { TextButton(onClick = { a.sheet = null }) { Text("Cancel", color = Red) } }
        )
    } else if (sh != null) {
        ModalBottomSheet(onDismissRequest = { a.sheet = null }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = SheetC, contentColor = Color.White) {
            AnimatedContent(targetState = sh, transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(120)) }, label = "sheet") { s ->
                when (s) {
                    is Sheet.Menu -> MenuSheet(a, s.s, s.fromPlayer)
                    is Sheet.SortBy -> SortSheet(a)
                    is Sheet.SleepT -> SleepSheet(a)
                    is Sheet.Equal -> EqSheet(a)
                    is Sheet.QueueL -> QueueSheet(a)
                    is Sheet.SpeedS -> SpeedSheet(a)
                    is Sheet.AddTo -> AddToSheet(a, s.ids)
                    is Sheet.NewPl -> {}
                }
            }
        }
    }
    a.info?.let { s ->
        AlertDialog(
            onDismissRequest = { a.info = null }, containerColor = SheetC, titleContentColor = Color.White, textContentColor = Color.White,
            title = { Text("Song info") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Title" to s.title, "Artist" to s.artist, "Album" to s.album, "Duration" to fmt(s.dur), "Size" to "%.1f MB".format(s.size / 1048576.0), "File" to s.file, "Path" to s.path).forEach { (k, v) ->
                        Column { Text(k, fontSize = 12.sp, color = Cyan); Text(v, fontSize = 14.sp) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { a.info = null }) { Text("Close", color = Cyan) } }
        )
    }
}

@Composable
fun MenuSheet(a: App, s: Song, fromPlayer: Boolean) {
    val isFav = s.id in a.favs
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Text("Cancel", color = Red, fontSize = 17.sp, modifier = Modifier.bounceClick { a.sheet = null }.padding(horizontal = 24.dp, vertical = 10.dp))
        MI(Icons.Rounded.SkipNext, "Play next") { a.sheet = null; a.playNext(s) }
        MI(Icons.Rounded.QueueMusic, "Add to play queue") { a.sheet = null; a.addQueue(s) }
        MI(Icons.Rounded.PlaylistAdd, "Add to Playlist") { a.sheet = Sheet.AddTo(listOf(s.id)) }
        if (!fromPlayer) {
            MI(if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, if (isFav) "Remove from favorites" else "Add to favorites") {
                a.sheet = null
                a.toggleFav(s.id)
                a.showNote(if (isFav) "Removed from favourites" else "Added to favourites")
            }
        }
        if (!fromPlayer && a.curPage == 2 && a.openList != null) {
            MI(Icons.Rounded.PlaylistRemove, "Remove from playlist") { a.sheet = null; a.removeFromPlaylist(a.openList ?: "", setOf(s.id)) }
        }
        MI(Icons.Rounded.Album, "Album: " + s.album) { a.sheet = null; a.q = s.album; a.searching = true }
        MI(Icons.Rounded.Info, "Song Info") { a.sheet = null; a.info = s }
        MI(Icons.Rounded.NotificationsActive, "Set Ringtone") { a.sheet = null; a.ringtone(s) }
        MI(Icons.Rounded.Share, "Share local file") { a.sheet = null; a.share(s) }
        MI(Icons.Rounded.Delete, "Delete") { a.sheet = null; a.deleteSongs(listOf(s)) }
    }
}

@Composable
fun SortSheet(a: App) {
    Column(Modifier.padding(bottom = 24.dp)) {
        SheetTitle("Sort order")
        listOf("Sort by song title", "Sort by date added", "Sort by play count").forEachIndexed { i, n ->
            MI(if (a.sort == i) Icons.Rounded.Check else Icons.Rounded.Sort, n) { a.sort = i; a.store.sort = i; a.sheet = null }
        }
    }
}

@Composable
fun SleepSheet(a: App) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(40) } }
    Column(Modifier.fillMaxWidth().padding(bottom = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        SheetTitle("Sleep timer")
        if (Sleep.endAt > 0) {
            val left = (Sleep.endAt - now).coerceAtLeast(0L)
            val frac = (left.toFloat() / Sleep.total).coerceIn(0f, 1f)
            Box(Modifier.size(190.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize().padding(10.dp)) {
                    val sw = 10.dp.toPx()
                    drawArc(Color(0xFF16213D), -90f, 360f, false, style = Stroke(sw))
                    drawArc(Cyan, -90f, 360f * frac, false, style = Stroke(sw, cap = StrokeCap.Round))
                }
                Text(fmt(left), fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Cyan)
            }
            Spacer(Modifier.height(10.dp))
            Chip("Turn off timer", true) { Sleep.cancel(); a.sheet = null }
        } else {
            Column(Modifier.fillMaxWidth()) {
                listOf(15, 30, 45, 60).forEach { m -> MI(Icons.Rounded.Schedule, "$m minutes") { Sleep.start(m); a.sheet = null; a.toast("Music will stop in $m minutes") } }
            }
        }
    }
}

@Composable
fun EqSheet(a: App) {
    val eq = PlayerService.eq
    val bass = PlayerService.bass
    val scope = rememberCoroutineScope()
    Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 24.dp).padding(bottom = 28.dp)) {
        Text("Equalizer", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        if (eq == null) {
            Spacer(Modifier.height(12.dp))
            Text("The equalizer isn’t ready yet. Play a song first, then open this again.", color = Mute)
        } else {
            val n = eq.numberOfBands.toInt()
            val lo = eq.bandLevelRange[0].toFloat()
            val hi = eq.bandLevelRange[1].toFloat()
            val lv = remember { mutableStateListOf<Int>().also { l -> for (i in 0 until n) l.add(eq.getBandLevel(i.toShort()).toInt()) } }
            var on by remember { mutableStateOf(eq.getEnabled()) }
            var bs by remember { mutableFloatStateOf(a.store.bass.toFloat()) }
            var selP by remember { mutableIntStateOf(-2) }
            val dim by animateFloatAsState(if (on) 1f else 0.3f, tween(300), label = "eqdim")
            val sc = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF16213D), disabledThumbColor = Color.White, disabledActiveTrackColor = Cyan, disabledInactiveTrackColor = Color(0xFF16213D))
            fun glide(to: List<Int>) {
                val from = lv.toList()
                scope.launch {
                    for (s in 1..16) {
                        delay(16)
                        val f = FastOutSlowInEasing.transform(s / 16f)
                        for (i in 0 until n) lv[i] = (from[i] + (to[i] - from[i]) * f).toInt()
                    }
                    a.store.saveEq(lv.toList(), on)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (on) "Enabled" else "Disabled", color = if (on) Cyan else Mute, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Switch(checked = on, onCheckedChange = { on = it; eq.setEnabled(it); a.store.saveEq(lv.toList(), it) }, colors = SwitchDefaults.colors(checkedTrackColor = Cyan, checkedThumbColor = Dark))
            }
            Column(Modifier.graphicsLayer { alpha = dim }) {
                val np = eq.numberOfPresets.toInt()
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Flat", selP == -1, Yellow) {
                        if (on) {
                            for (i in 0 until n) eq.setBandLevel(i.toShort(), 0.toShort())
                            selP = -1
                            glide(List(n) { 0 })
                        }
                    }
                    for (p in 0 until np) {
                        Chip(eq.getPresetName(p.toShort()), selP == p, Yellow) {
                            if (on) {
                                eq.usePreset(p.toShort())
                                selP = p
                                glide(List(n) { eq.getBandLevel(it.toShort()).toInt() })
                            }
                        }
                    }
                }
                Text("Bass boost", color = Cyan, fontSize = 13.sp)
                if (bass == null) Text("Bass boost isn’t supported on this phone.", color = Mute, fontSize = 13.sp) else Slider(
                    value = bs, onValueChange = { bs = it; bass.setStrength(it.toInt().toShort()) }, onValueChangeFinished = { a.store.bass = bs.toInt() },
                    enabled = on, valueRange = 0f..1000f, colors = sc
                )
                for (i in 0 until n) {
                    Text(hz(eq.getCenterFreq(i.toShort())), color = Cyan, fontSize = 13.sp)
                    Slider(
                        value = lv[i].toFloat().coerceIn(lo, hi),
                        onValueChange = { v -> lv[i] = v.toInt(); selP = -2; eq.setBandLevel(i.toShort(), v.toInt().toShort()) },
                        onValueChangeFinished = { a.store.saveEq(lv.toList(), on) },
                        enabled = on, valueRange = lo..hi, colors = sc
                    )
                }
            }
        }
    }
}

@Composable
fun QueueSheet(a: App) {
    Column(Modifier.padding(bottom = 16.dp)) {
        SheetTitle("Queue (${a.queue.size})")
        LazyColumn(Modifier.heightIn(max = 460.dp)) {
            itemsIndexed(a.queue) { i, m ->
                val on = m.mediaId == a.curId?.toString()
                Row(Modifier.fillMaxWidth().bounceClick { a.ctl?.seekTo(i, 0L); a.ctl?.play() }.padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}", color = if (on) Red else Cyan, modifier = Modifier.width(36.dp))
                    Column {
                        Text(m.mediaMetadata.title?.toString() ?: "", color = if (on) Cyan else Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(m.mediaMetadata.artist?.toString() ?: "", color = Mute, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun AddToSheet(a: App, ids: List<Long>) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        SheetTitle("Add to playlist")
        MI(Icons.Rounded.Add, "New playlist") { a.sheet = Sheet.NewPl(ids) }
        a.lists.keys.toList().forEach { name ->
            MI(Icons.Rounded.QueueMusic, name) { a.addToPlaylist(name, ids); a.sheet = null; a.sel = emptySet(); a.toast("Added to $name") }
        }
    }
}

@Composable
fun SpeedSheet(a: App) {
    Column(Modifier.padding(bottom = 24.dp)) {
        SheetTitle("Playback speed")
        listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
            val on = kotlin.math.abs(a.speed - s) < 0.01f
            MI(if (on) Icons.Rounded.Check else Icons.Rounded.Speed, (if (s == 1f) "Normal (1.0x)" else "${s}x")) { a.changeSpeed(s); a.sheet = null }
        }
    }
}
