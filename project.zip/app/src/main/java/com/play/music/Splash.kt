package com.play.music

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun Splash(onDone: () -> Unit) {
    val t = remember { Animatable(0f) }
    val drop = remember { Animatable(-1f) }
    val fade = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        launch { t.animateTo(1f, tween(650, easing = FastOutSlowInEasing)) }
        delay(420)
        drop.animateTo(0f, tween(380, easing = FastOutLinearInEasing))
        drop.animateTo(-0.22f, tween(170, easing = LinearOutSlowInEasing))
        drop.animateTo(0f, tween(170, easing = FastOutLinearInEasing))
        drop.animateTo(-0.07f, tween(110, easing = LinearOutSlowInEasing))
        drop.animateTo(0f, tween(110, easing = FastOutLinearInEasing))
        delay(380)
        fade.animateTo(0f, tween(400))
        onDone()
    }
    Box(
        Modifier.fillMaxSize().graphicsLayer { alpha = fade.value }.background(bgBrush()).pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                "Play", color = Cyan, fontSize = 64.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.graphicsLayer {
                    alpha = t.value; scaleX = 0.85f + 0.15f * t.value; scaleY = 0.85f + 0.15f * t.value; translationY = (1f - t.value) * 40f
                }
            )
            Box(
                Modifier.padding(start = 4.dp, bottom = 18.dp).offset(y = 180.dp * drop.value)
                    .graphicsLayer { alpha = if (drop.value > -0.98f) 1f else 0f }
                    .size(14.dp).clip(CircleShape).background(Red)
            )
        }
    }
}
