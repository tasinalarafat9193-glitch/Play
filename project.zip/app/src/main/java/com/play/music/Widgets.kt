package com.play.music

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews

object WidgetHelper {
    const val PLAY = "com.play.music.W_PLAY"
    const val NEXT = "com.play.music.W_NEXT"
    const val PREV = "com.play.music.W_PREV"

    private fun all(): List<Pair<Class<*>, Int>> = listOf(
        PillWidget::class.java to R.layout.widget_pill,
        VinylWidget::class.java to R.layout.widget_vinyl,
        BarsWidget::class.java to R.layout.widget_bars
    )

    fun update(ctx: Context) {
        try {
            val mgr = AppWidgetManager.getInstance(ctx)
            for ((cls, layout) in all()) {
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
                if (ids.isNotEmpty()) mgr.updateAppWidget(ids, build(ctx, layout, cls))
            }
        } catch (e: Exception) {
        }
    }

    private fun act(ctx: Context, cls: Class<*>, action: String): PendingIntent =
        PendingIntent.getBroadcast(ctx, (action + cls.name).hashCode(), Intent(ctx, cls).setAction(action), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun build(ctx: Context, layout: Int, cls: Class<*>): RemoteViews {
        val p = PlayerService.player
        val rv = RemoteViews(ctx.packageName, layout)
        rv.setTextViewText(R.id.w_title, p?.mediaMetadata?.title?.toString() ?: "Play")
        rv.setTextViewText(R.id.w_artist, p?.mediaMetadata?.artist?.toString() ?: "Tap to open")
        rv.setImageViewResource(R.id.w_play, if (p?.isPlaying == true) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        rv.setOnClickPendingIntent(R.id.w_play, act(ctx, cls, PLAY))
        rv.setOnClickPendingIntent(R.id.w_next, act(ctx, cls, NEXT))
        rv.setOnClickPendingIntent(R.id.w_prev, act(ctx, cls, PREV))
        rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        return rv
    }

    fun pin(ctx: Context, cls: Class<*>): Boolean {
        return try {
            val m = AppWidgetManager.getInstance(ctx)
            Build.VERSION.SDK_INT >= 26 && m.isRequestPinAppWidgetSupported && m.requestPinAppWidget(ComponentName(ctx, cls), null, null)
        } catch (e: Exception) {
            false
        }
    }
}

open class PlayWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetHelper.update(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        val p = PlayerService.player
        when (intent.action) {
            WidgetHelper.PLAY -> if (p != null) { if (p.isPlaying) p.pause() else p.play() } else openApp(context)
            WidgetHelper.NEXT -> if (p != null) p.seekToNext() else openApp(context)
            WidgetHelper.PREV -> if (p != null) p.seekToPrevious() else openApp(context)
        }
        super.onReceive(context, intent)
    }

    private fun openApp(c: Context) {
        try {
            c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
    }
}

class PillWidget : PlayWidget()
class VinylWidget : PlayWidget()
class BarsWidget : PlayWidget()
