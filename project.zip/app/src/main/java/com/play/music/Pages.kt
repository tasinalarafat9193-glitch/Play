package com.play.music

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class Preset(val name: String, val a: Long, val b: Long, val t: Long)

val presets = listOf(
    Preset("Cyan Night", 0xFF22E6FF, 0xFFFF2D55, 0xFF0B1C4D),
    Preset("Ocean", 0xFF4DA3FF, 0xFF00E5C3, 0xFF0A2A5C),
    Preset("Sunset", 0xFFFF8A3D, 0xFFFF3D81, 0xFF4A1530),
    Preset("Violet", 0xFFB388FF, 0xFFFF6EC7, 0xFF2A1459),
    Preset("Emerald", 0xFF2CFF9A, 0xFFFFD93D, 0xFF0B3B2C),
    Preset("Rose", 0xFFFF5C8A, 0xFFFFB36B, 0xFF4A1022),
    Preset("Gold", 0xFFFFC93C, 0xFFFF5C5C, 0xFF3A2A08),
    Preset("Mono", 0xFFE8E8E8, 0xFF8AB4FF, 0xFF1C1C1C)
)

val swatches = listOf(
    0xFF22E6FF, 0xFF4DA3FF, 0xFF2563FF, 0xFFB388FF, 0xFFFF6EC7, 0xFFFF2D55, 0xFFFF8A3D,
    0xFFFFC93C, 0xFF2CFF9A, 0xFF00E5C3, 0xFFFFFFFF, 0xFFB0B8C8, 0xFFFF5C8A, 0xFF9CFF3D
)

val tints = listOf(0xFF0B1C4D, 0xFF2A1459, 0xFF4A1530, 0xFF0B3B2C, 0xFF4A1022, 0xFF3A2A08, 0xFF1C1C1C, 0xFF04060C)

@Composable
fun PageScaffold(title: String, onBack: () -> Unit, fixed: @Composable () -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(bgBrush()).pointerInput(Unit) { detectTapGestures { } }) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TopIcon(Icons.Rounded.ArrowBackIosNew, "Back", onClick = onBack)
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(start = 14.dp))
        }
        fixed()
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp), content = content)
    }
}

@Composable
fun SettingsRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().bounceClick(onClick = onClick).clip(R16).background(CardC).border(1.dp, LineC, R16).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Cyan.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Cyan) }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            Text(sub, fontSize = 12.sp, color = Mute)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = Cyan)
    }
}

@Composable
fun SettingsPage(a: App) {
    PageScaffold("Settings", { a.page = null }) {
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SettingsRow(Icons.Rounded.Palette, "Appearance", "Colours, background and gradient") { a.page = "look" }
            SettingsRow(Icons.Rounded.Widgets, "Home Screen Widget", "Add a Play widget to your home screen") { a.page = "widget" }
            SettingsRow(Icons.Rounded.Info, "About Play", "Version and creator") { a.page = "about" }
        }
    }
}

@Composable
fun ThemePreview() {
    val cap = RoundedCornerShape(999.dp)
    Box(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.width(150.dp).height(250.dp).clip(RoundedCornerShape(22.dp)).border(2.dp, Color(0xFF2A3558), RoundedCornerShape(22.dp)).background(bgBrush())) {
            Column(Modifier.padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Play", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    Text(".", color = Red, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.weight(1f))
                    repeat(3) { Box(Modifier.padding(start = 4.dp).size(11.dp).clip(CircleShape).border(1.dp, Cyan, CircleShape)) }
                }
                Spacer(Modifier.height(7.dp))
                Box(Modifier.fillMaxWidth().height(18.dp).clip(cap).background(Cyan.copy(alpha = 0.10f))) {
                    Box(Modifier.width(32.dp).fillMaxHeight().padding(2.dp).clip(cap).background(Cyan.copy(alpha = 0.28f)).border(1.dp, Cyan.copy(alpha = 0.6f), cap))
                }
                Spacer(Modifier.height(7.dp))
                repeat(4) { i ->
                    Column(
                        Modifier.fillMaxWidth().padding(bottom = 5.dp).clip(RoundedCornerShape(9.dp)).background(CardC)
                            .border(1.dp, if (i == 1) Red else LineC, RoundedCornerShape(9.dp)).padding(7.dp)
                    ) {
                        Box(Modifier.width(62.dp).height(5.dp).clip(cap).background(if (i == 1) Cyan else Color.White.copy(alpha = 0.85f)))
                        Spacer(Modifier.height(4.dp))
                        Box(Modifier.width(40.dp).height(4.dp).clip(cap).background(Mute))
                    }
                }
            }
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(8.dp).height(32.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFF111A30))
                    .border(1.dp, LineC, RoundedCornerShape(13.dp)).padding(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(20.dp).clip(RoundedCornerShape(7.dp)).background(Cyan))
                Spacer(Modifier.width(6.dp))
                Box(Modifier.weight(1f).height(5.dp).clip(cap).background(Cyan))
                Spacer(Modifier.width(6.dp))
                Box(Modifier.size(18.dp).clip(CircleShape).background(Red))
            }
        }
    }
}

@Composable
fun Swatch(c: Long, selected: Boolean, onClick: () -> Unit) {
    val bc by animateColorAsState(if (selected) Color.White else Color.Transparent, tween(200), label = "sw")
    Box(Modifier.size(34.dp).bounceClick(onClick = onClick).clip(CircleShape).background(Color(c)).border(2.dp, bc, CircleShape))
}

@Composable
fun LookPage(a: App) {
    val hsv = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(Theme.accent.toArgb(), it) } }
    var h by remember { mutableFloatStateOf(hsv[0]) }
    var s by remember { mutableFloatStateOf(hsv[1]) }
    var v by remember { mutableFloatStateOf(hsv[2]) }
    PageScaffold("Appearance", { a.page = "settings" }, fixed = { ThemePreview() }) {
        Spacer(Modifier.height(10.dp))
        Text("Themes", color = Cyan, fontSize = 13.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            presets.forEach { p ->
                val on = Theme.accent == Color(p.a) && Theme.accent2 == Color(p.b)
                Column(Modifier.bounceClick {
                    Theme.accent = Color(p.a); Theme.accent2 = Color(p.b); Theme.tint = Color(p.t); a.saveTheme()
                }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(56.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(p.a), Color(p.b)))).border(2.dp, if (on) Color.White else LineC, CircleShape))
                    Text(p.name, fontSize = 11.sp, color = if (on) Color.White else Cyan, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Gradient background", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = Theme.gradient, onCheckedChange = { Theme.gradient = it; a.saveTheme() }, colors = SwitchDefaults.colors(checkedTrackColor = Cyan, checkedThumbColor = Dark))
        }
        Spacer(Modifier.height(14.dp))
        Text("Background colour", color = Cyan, fontSize = 13.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            tints.forEach { c -> Swatch(c, Theme.tint == Color(c)) { Theme.tint = Color(c); a.saveTheme() } }
        }
        Text("Accent colour", color = Cyan, fontSize = 13.sp)
        swatches.chunked(7).forEach { row ->
            Row(Modifier.padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { c -> Swatch(c, Theme.accent == Color(c)) { Theme.accent = Color(c); a.saveTheme() } }
            }
        }
        Text("Custom colour", color = Cyan, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        val cs = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF16213D))
        Text("Hue", fontSize = 12.sp, color = Color.White)
        Slider(h, { h = it; Theme.accent = Color.hsv(h, s, v) }, valueRange = 0f..360f, onValueChangeFinished = { a.saveTheme() }, colors = cs)
        Text("Saturation", fontSize = 12.sp, color = Color.White)
        Slider(s, { s = it; Theme.accent = Color.hsv(h, s, v) }, valueRange = 0f..1f, onValueChangeFinished = { a.saveTheme() }, colors = cs)
        Text("Brightness", fontSize = 12.sp, color = Color.White)
        Slider(v, { v = it; Theme.accent = Color.hsv(h, s, v) }, valueRange = 0.3f..1f, onValueChangeFinished = { a.saveTheme() }, colors = cs)
        Text("Highlight colour", color = Cyan, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        swatches.chunked(7).forEach { row ->
            Row(Modifier.padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { c -> Swatch(c, Theme.accent2 == Color(c)) { Theme.accent2 = Color(c); a.saveTheme() } }
            }
        }
    }
}

@Composable
fun WidgetCard(name: String, desc: String, a: App, cls: Class<*>, preview: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(R16).background(CardC).border(1.dp, LineC, R16).padding(14.dp)) {
        preview()
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                Text(desc, fontSize = 12.sp, color = Mute)
            }
            Chip("Add", true) {
                if (!WidgetHelper.pin(a.ctx, cls)) a.toast("Long-press your home screen, tap Widgets, then pick Play")
            }
        }
    }
}

@Composable
fun WidgetPage(a: App) {
    PageScaffold("Home Screen Widget", { a.page = "settings" }) {
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            WidgetCard("Pill", "Slim player bar, 4 x 1", a, PillWidget::class.java) {
                Row(Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp)).background(Color(0xFF0C1220)).border(1.dp, Color(0xFF1A2540), RoundedCornerShape(26.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2563FF)), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MusicNote, null, tint = Color(0xFF22E6FF), modifier = Modifier.size(20.dp)) }
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text("Song title", fontSize = 13.sp, maxLines = 1, color = Color.White); Text("Artist", fontSize = 11.sp, color = Mute) }
                    Icon(Icons.Rounded.SkipPrevious, null, tint = Color(0xFF22E6FF))
                    Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF22E6FF)), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.PlayArrow, null, tint = Color(0xFF021022)) }
                    Icon(Icons.Rounded.SkipNext, null, tint = Color(0xFF22E6FF))
                }
            }
            WidgetCard("Vinyl", "Square card with a record, 2 x 2", a, VinylWidget::class.java) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.verticalGradient(listOf(Color(0xFF0B1C4D), Color(0xFF04060C)))).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(64.dp).clip(CircleShape).background(Color(0xFF0A1328)).border(2.dp, Color(0xFF22E6FF), CircleShape), contentAlignment = Alignment.Center) { Box(Modifier.size(24.dp).clip(CircleShape).background(Color(0xFFFF2D55))) }
                    Text("Song title", fontSize = 13.sp, color = Color.White, modifier = Modifier.padding(top = 6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.SkipPrevious, null, tint = Color(0xFF22E6FF))
                        Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF22E6FF)), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.PlayArrow, null, tint = Color(0xFF021022), modifier = Modifier.size(20.dp)) }
                        Icon(Icons.Rounded.SkipNext, null, tint = Color(0xFF22E6FF))
                    }
                }
            }
            WidgetCard("Beats", "Wide card with bars, 4 x 2", a, BarsWidget::class.java) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF123A8F), Color(0xFF04060C)))).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Song title", fontSize = 15.sp, color = Color.White); Text("Artist", fontSize = 11.sp, color = Color(0xFFA9B8D8)) }
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom, modifier = Modifier.height(34.dp)) {
                            listOf(14, 24, 34, 20, 12, 28).forEachIndexed { i, hh -> Box(Modifier.width(5.dp).height(hh.dp).clip(RoundedCornerShape(2.dp)).background(if (i % 2 == 0) Color(0xFF22E6FF) else Color(0xFFFF2D55))) }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.SkipPrevious, null, tint = Color(0xFF22E6FF))
                        Box(Modifier.size(38.dp).clip(CircleShape).background(Color(0xFF22E6FF)), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.PlayArrow, null, tint = Color(0xFF021022)) }
                        Icon(Icons.Rounded.SkipNext, null, tint = Color(0xFF22E6FF))
                    }
                }
            }
        }
    }
}

@Composable
fun AboutPage(a: App) {
    val ver = try { a.ctx.packageManager.getPackageInfo(a.ctx.packageName, 0).versionName } catch (e: Exception) { "3.0" }
    PageScaffold("About Play", { a.page = "settings" }) {
        Spacer(Modifier.height(40.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("Play", color = Cyan, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
                Text(".", color = Red, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(18.dp))
            Text("Version $ver", fontSize = 16.sp, color = Color.White)
            Spacer(Modifier.height(6.dp))
            Text("Creator: Tasin Al Arafat", fontSize = 16.sp, color = Cyan)
        }
    }
}
