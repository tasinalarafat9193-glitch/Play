package com.play.music

import android.content.Context
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

object Sleep {
    private val h = Handler(Looper.getMainLooper())
    var endAt by mutableLongStateOf(0L)
    fun start(min: Int) {
        cancel()
        endAt = System.currentTimeMillis() + min * 60000L
        h.postDelayed({ PlayerService.player?.pause(); endAt = 0L }, min * 60000L)
    }
    fun cancel() {
        h.removeCallbacksAndMessages(null)
        endAt = 0L
    }
}

class PlayerService : MediaSessionService() {
    private var session: MediaSession? = null

    companion object {
        var player: ExoPlayer? = null
        var eq: Equalizer? = null
    }

    override fun onCreate() {
        super.onCreate()
        val p = ExoPlayer.Builder(this)
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        val sid = (getSystemService(Context.AUDIO_SERVICE) as AudioManager).generateAudioSessionId()
        p.setAudioSessionId(sid)
        try {
            val sp = getSharedPreferences("play", Context.MODE_PRIVATE)
            val e = Equalizer(0, sid)
            val lv = (sp.getString("eq", "") ?: "").split(",").mapNotNull { it.toShortOrNull() }
            if (lv.size == e.numberOfBands.toInt()) lv.forEachIndexed { i, v -> e.setBandLevel(i.toShort(), v) }
            e.setEnabled(sp.getBoolean("eq_on", true))
            eq = e
        } catch (ex: Exception) {
        }
        player = p
        session = MediaSession.Builder(this, p).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        try { eq?.release() } catch (e: Exception) {}
        eq = null
        player = null
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        super.onDestroy()
    }
}
