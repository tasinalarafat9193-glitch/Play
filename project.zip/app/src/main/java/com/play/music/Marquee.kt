package com.play.music

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun Marquee(text: String, color: Color, size: TextUnit, run: Boolean, modifier: Modifier = Modifier, weight: FontWeight = FontWeight.Normal) {
    var cw by remember { mutableIntStateOf(0) }
    var tw by remember { mutableIntStateOf(0) }
    val off = remember { Animatable(0f) }
    val d = LocalDensity.current.density
    val gap = 40f * d
    LaunchedEffect(text, run, tw, cw) {
        off.snapTo(0f)
        if (run && cw > 0 && tw > cw) {
            delay(900)
            while (true) {
                val dist = tw + gap
                off.animateTo(-dist, tween(durationMillis = (dist / d * 24f).toInt().coerceAtLeast(2500), easing = LinearEasing))
                off.snapTo(0f)
            }
        }
    }
    androidx.compose.foundation.layout.Box(modifier.clipToBounds().onSizeChanged { cw = it.width }) {
        Row(Modifier.wrapContentWidth(Alignment.Start, unbounded = true).graphicsLayer { translationX = off.value }) {
            Text(text, color = color, fontSize = size, fontWeight = weight, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip, modifier = Modifier.onSizeChanged { tw = it.width })
            if (tw > cw) {
                Spacer(Modifier.width(40.dp))
                Text(text, color = color, fontSize = size, fontWeight = weight, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip)
            }
        }
    }
}
