package com.play.music

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private lateinit var app: App

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { window.attributes = window.attributes.apply { preferredRefreshRate = 120f } } catch (e: Exception) {}
        app = App(this, Store(this))
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { PlayApp(app) } }
    }

    override fun onStart() {
        super.onStart()
        app.startTick++
    }

    override fun onStop() {
        app.miniShown = false
        app.saveState()
        super.onStop()
    }
}

@Composable
fun PlayerHost(a: App) {
    if (a.exp.value > 0.001f) FullPlayer(a)
}

@Composable
fun PlayApp(a: App) {
    val ctx = LocalContext.current
    a.scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[a.perm] == true) { a.granted = true; a.reload() }
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> a.micGranted = ok }
    a.delLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) a.finishDelete() else a.pendingDelete = emptyList()
    }
    a.askPerm = { launcher.launch(arrayOf(a.perm)) }
    a.askMic = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }

    LaunchedEffect(Unit) {
        if (a.hasPerm()) {
            a.reload()
        } else {
            a.loaded = true
            launcher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(a.perm, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(a.perm))
        }
    }
    DisposableEffect(Unit) {
        val f = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlayerService::class.java))).buildAsync()
        f.addListener({ a.attach(f.get()) }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(f) }
    }
    LaunchedEffect(a.ctl) {
        var tick = 0
        while (true) {
            val c = a.ctl
            if (!a.drag) a.pos = c?.currentPosition ?: 0L
            if (c != null && c.isPlaying) {
                val id = a.curId
                if (id != null && a.counted != id && a.pos > 15000L) { a.counted = id; a.bump(id) }
                tick++
                if (tick % 20 == 0) a.saveState()
            }
            delay(250)
        }
    }
    LaunchedEffect(a.startTick, a.curId != null) {
        if (a.curId != null) { delay(260); a.miniShown = true }
    }
    BackHandler(enabled = a.exp.value > 0.5f) { a.collapse() }
    BackHandler(enabled = a.exp.value <= 0.5f && a.sel.isNotEmpty()) { a.sel = emptySet() }
    BackHandler(enabled = a.exp.value <= 0.5f && a.sel.isEmpty() && a.searching) { a.q = ""; a.searching = false }
    BackHandler(enabled = a.exp.value <= 0.5f && a.sel.isEmpty() && !a.searching && (a.openList != null || a.openFolder != null)) { a.openList = null; a.openFolder = null }

    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxSize().background(bgBrush())) {
        SideEffect { a.hPx = with(density) { maxHeight.toPx() } }
        MainScreen(a)
        AnimatedVisibility(
            visible = a.curId != null && a.miniShown,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.8f, stiffness = 300f)) { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) { MiniBar(a, Modifier) }
        PlayerHost(a)
        SheetHost(a)
    }
}
