package com.play.music

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val Bg = Color(0xFF04060C)
val CardC = Color(0xFF0C1220)
val LineC = Color(0xFF1A2540)
val Blue = Color(0xFF2563FF)
val Cyan = Color(0xFF22E6FF)
val Red = Color(0xFFFF2D55)
val Mute = Color(0xFF8592B0)
val SheetC = Color(0xFF14171F)
val Dark = Color(0xFF021022)
val R16 = RoundedCornerShape(16.dp)
val R28 = RoundedCornerShape(28.dp)

sealed class Sheet {
    data class Menu(val s: Song) : Sheet()
    object SortBy : Sheet()
    object SleepT : Sheet()
    object Equal : Sheet()
    object QueueL : Sheet()
    data class AddTo(val ids: List<Long>) : Sheet()
    data class NewPl(val ids: List<Long>) : Sheet()
}

class App(val ctx: Context, val store: Store) {
    var songs by mutableStateOf<List<Song>>(emptyList())
    var granted by mutableStateOf(false)
    var favs by mutableStateOf(store.favs())
    var lists by mutableStateOf(store.playlists())
    var sort by mutableIntStateOf(store.sort)
    var q by mutableStateOf("")
    var tab by mutableIntStateOf(0)
    var openList by mutableStateOf<String?>(null)
    var sel by mutableStateOf<Set<Long>>(emptySet())
    var ctl by mutableStateOf<MediaController?>(null)
    var curId by mutableStateOf<Long?>(null)
    var title by mutableStateOf("")
    var artist by mutableStateOf("")
    var playing by mutableStateOf(false)
    var pos by mutableLongStateOf(0L)
    var dur by mutableLongStateOf(0L)
    var drag by mutableStateOf(false)
    var shuffle by mutableStateOf(false)
    var rep by mutableIntStateOf(0)
    var queue by mutableStateOf<List<MediaItem>>(emptyList())
    var expanded by mutableStateOf(false)
    var sheet by mutableStateOf<Sheet?>(null)
    var info by mutableStateOf<Song?>(null)
    var delLauncher: ManagedActivityResultLauncher<IntentSenderRequest, ActivityResult>? = null
    var askPerm: () -> Unit = {}

    val byId: Map<Long, Song> get() = songs.associateBy { it.id }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    fun reload() { songs = loadSongs(ctx); sel = emptySet() }

    fun visible(): List<Song> {
        val base: List<Song> = when {
            tab == 1 -> songs.filter { it.id in favs }
            tab == 2 -> { val m = byId; (openList?.let { lists[it] } ?: emptyList()).mapNotNull { m[it] } }
            else -> songs
        }
        val f = if (q.isBlank()) base else base.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
        if (tab == 2) return f
        return when (sort) {
            1 -> f.sortedBy { it.artist.lowercase() }
            2 -> f.sortedByDescending { it.added }
            3 -> f.sortedBy { it.added }
            else -> f.sortedBy { it.title.lowercase() }
        }
    }

    fun item(s: Song): MediaItem = MediaItem.Builder().setMediaId(s.id.toString()).setUri(s.uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).build()).build()

    fun playList(l: List<Song>, i: Int) {
        val c = ctl ?: return
        if (l.isEmpty()) return
        c.setMediaItems(l.map { item(it) }, i, 0L)
        c.prepare()
        c.play()
    }

    fun playNext(s: Song) {
        val c = ctl ?: return
        if (c.mediaItemCount == 0) playList(listOf(s), 0) else { c.addMediaItem(c.currentMediaItemIndex + 1, item(s)); toast("Will play next") }
    }

    fun addQueue(s: Song) {
        val c = ctl ?: return
        if (c.mediaItemCount == 0) playList(listOf(s), 0) else { c.addMediaItem(item(s)); toast("Added to queue") }
    }

    fun toggleSel(id: Long) { sel = if (id in sel) sel - id else sel + id }
    fun toggleFav(id: Long) { favs = if (id in favs) favs - id else favs + id; store.saveFavs(favs) }

    fun addToPlaylist(name: String, ids: List<Long>) {
        val old = lists[name] ?: emptyList()
        lists = lists + (name to (old + ids.filter { it !in old }))
        store.savePlaylists(lists)
    }

    fun deletePlaylist(name: String) { lists = lists - name; store.savePlaylists(lists) }

    fun removeFromPlaylist(name: String, ids: Set<Long>) {
        lists = lists + (name to (lists[name] ?: emptyList()).filter { it !in ids })
        store.savePlaylists(lists)
        sel = emptySet()
    }

    fun attach(c: MediaController) {
        ctl = c
        c.addListener(object : Player.Listener {
            override fun onEvents(p: Player, e: Player.Events) { sync(p, e.contains(Player.EVENT_TIMELINE_CHANGED)) }
        })
        sync(c, true)
    }

    fun sync(p: Player, tl: Boolean) {
        playing = p.isPlaying
        curId = p.currentMediaItem?.mediaId?.toLongOrNull()
        title = p.mediaMetadata.title?.toString() ?: ""
        artist = p.mediaMetadata.artist?.toString() ?: ""
        dur = maxOf(p.duration, 0L)
        shuffle = p.shuffleModeEnabled
        rep = p.repeatMode
        if (tl) queue = List(p.mediaItemCount) { p.getMediaItemAt(it) }
    }

    fun deleteSongs(l: List<Song>) {
        if (l.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, l.map { it.uri })
                delLauncher?.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) { toast("Couldn’t delete") }
        } else {
            var ok = 0
            l.forEach { try { ctx.contentResolver.delete(it.uri, null, null); ok++ } catch (e: Exception) {} }
            if (ok > 0) reload() else toast("Couldn’t delete")
        }
    }

    fun ringtone(s: Song) {
        try {
            if (!Settings.System.canWrite(ctx)) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                toast("Allow “Modify system settings”, then try again")
                return
            }
            RingtoneManager.setActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_RINGTONE, s.uri)
            toast("Ringtone set")
        } catch (e: Exception) { toast("Couldn’t set ringtone") }
    }

    fun share(s: Song) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "audio/*"
        i.putExtra(Intent.EXTRA_STREAM, s.uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { PlayApp() } }
    }
}

@Composable
fun PlayApp() {
    val ctx = LocalContext.current
    val a = remember { App(ctx, Store(ctx)) }
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[perm] == true) { a.granted = true; a.reload() }
    }
    a.delLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) a.reload()
    }
    a.askPerm = { launcher.launch(arrayOf(perm)) }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED) {
            a.granted = true; a.reload()
        } else {
            launcher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(perm, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(perm))
        }
    }
    DisposableEffect(Unit) {
        val f = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlayerService::class.java))).buildAsync()
        f.addListener({ a.attach(f.get()) }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(f) }
    }
    LaunchedEffect(a.ctl) {
        while (true) {
            if (!a.drag) a.pos = a.ctl?.currentPosition ?: 0L
            delay(400)
        }
    }
    BackHandler(enabled = a.expanded) { a.expanded = false }
    BackHandler(enabled = !a.expanded && a.sel.isNotEmpty()) { a.sel = emptySet() }
    BackHandler(enabled = !a.expanded && a.sel.isEmpty() && a.tab == 2 && a.openList != null) { a.openList = null }

    Surface(color = Bg, contentColor = Color.White, modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(colors = listOf(Color(0xFF0B1C4D), Bg), endY = 1400f)).statusBarsPadding().navigationBarsPadding()) {
            ListScreen(a)
            AnimatedVisibility(visible = a.expanded, enter = slideInVertically { it }, exit = slideOutVertically { it }) { FullPlayer(a) }
            SheetHost(a)
        }
    }
}

@Composable
fun Chip(text: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(999.dp)).background(Color(0xFF111A30)).border(1.dp, if (on) Cyan else LineC, RoundedCornerShape(999.dp))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp)
    ) { Text(text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (on) Cyan else Color.White) }
}

@Composable
fun Header(a: App) {
    Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 6.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Play", color = Cyan, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text(".", color = Red, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.weight(1f))
        IconButton(onClick = { a.sheet = Sheet.SortBy }) { Icon(Icons.Rounded.Sort, "Sort", tint = Cyan) }
        IconButton(onClick = { a.sheet = Sheet.Equal }) { Icon(Icons.Rounded.GraphicEq, "Equalizer", tint = Cyan) }
        IconButton(onClick = { a.sheet = Sheet.SleepT }) { Icon(Icons.Rounded.Timer, "Sleep timer", tint = if (Sleep.endAt > 0) Red else Cyan) }
    }
}

@Composable
fun SelectBar(a: App, list: List<Song>) {
    val chosen = a.songs.filter { it.id in a.sel }
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { a.sel = emptySet() }, modifier = Modifier.size(42.dp)) { Icon(Icons.Rounded.Close, "Cancel selection", tint = Color.White) }
        Text("${a.sel.size} selected", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Cyan, maxLines = 1,
            modifier = Modifier.weight(1f).clickable { a.sel = list.map { it.id }.toSet() })
        IconButton(onClick = { a.favs = a.favs + a.sel; a.store.saveFavs(a.favs); a.sel = emptySet() }, modifier = Modifier.size(42.dp)) { Icon(Icons.Rounded.Favorite, "Add to favourites", tint = Red) }
        if (a.tab == 2 && a.openList != null) {
            IconButton(onClick = { a.removeFromPlaylist(a.openList ?: "", a.sel) }, modifier = Modifier.size(42.dp)) { Icon(Icons.Rounded.PlaylistRemove, "Remove from playlist", tint = Color.White) }
        }
        IconButton(onClick = { a.sheet = Sheet.AddTo(a.sel.toList()) }, modifier = Modifier.size(42.dp)) { Icon(Icons.Rounded.PlaylistAdd, "Add to playlist", tint = Color.White) }
        IconButton(onClick = { a.playList(list.filter { it.id in a.sel }, 0); a.sel = emptySet(); a.expanded = true }, modifier = Modifier.size(42.dp)) { Icon(Icons.Rounded.PlayArrow, "Play", tint = Cyan) }
        IconButton(onClick = { a.deleteSongs(chosen) }, modifier = Modifier.size(42.dp)) { Icon(Icons.Rounded.Delete, "Delete", tint = Color.White) }
    }
}

@Composable
fun ListScreen(a: App) {
    val list = remember(a.songs, a.favs, a.lists, a.sort, a.q, a.tab, a.openList) { a.visible() }
    val st = rememberLazyListState()
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        if (a.sel.isNotEmpty()) SelectBar(a, list) else Header(a)
        OutlinedTextField(
            value = a.q, onValueChange = { a.q = it }, singleLine = true,
            placeholder = { Text("Search songs", color = Mute) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Mute) },
            trailingIcon = { if (a.q.isNotEmpty()) IconButton(onClick = { a.q = "" }) { Icon(Icons.Rounded.Close, "Clear", tint = Mute) } },
            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = LineC, focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan)
        )
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Songs", "Favourites", "Playlists").forEachIndexed { i, t ->
                Chip(t, a.tab == i) { a.tab = i; a.openList = null; a.sel = emptySet() }
            }
        }
        if (a.tab == 2 && a.openList != null) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { a.openList = null }) { Icon(Icons.Rounded.ArrowBackIosNew, "Back", tint = Cyan) }
                Text(a.openList ?: "", fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Chip("Play all", true) { a.playList(list, 0); a.expanded = true }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (a.tab == 2 && a.openList == null) {
                PlaylistsView(a)
            } else if (list.isEmpty()) {
                Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (!a.granted) "Allow access to your music to see your songs" else if (a.tab == 1) "No favourite songs yet" else if (a.tab == 2) "This playlist is empty" else "No songs found",
                        color = Mute, fontSize = 14.sp
                    )
                    if (!a.granted) {
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { a.askPerm() }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Dark)) { Text("Allow access") }
                    }
                }
            } else {
                LazyColumn(
                    state = st,
                    contentPadding = PaddingValues(start = 16.dp, end = 34.dp, top = 4.dp, bottom = if (a.curId != null) 100.dp else 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(list, key = { _, s -> s.id }) { i, s -> SongRow(a, s, i, list) }
                }
                if (a.tab == 0 && a.sort == 0 && a.q.isBlank()) AzIndex(list, st, scope, Modifier.align(Alignment.CenterEnd))
            }
            if (a.curId != null) MiniBar(a, Modifier.align(Alignment.BottomCenter))
        }
    }
}

@Composable
fun AzIndex(list: List<Song>, st: LazyListState, scope: CoroutineScope, mod: Modifier) {
    val letters = ('A'..'Z').toList() + '#'
    var h by remember { mutableIntStateOf(1) }
    fun jump(y: Float) {
        val l = letters[((y / h) * letters.size).toInt().coerceIn(0, letters.size - 1)]
        val idx = if (l == '#') 0 else list.indexOfFirst { (it.title.firstOrNull()?.uppercaseChar() ?: '#') >= l }
        if (idx >= 0) scope.launch { st.scrollToItem(idx) }
    }
    Column(
        mod.fillMaxHeight().width(28.dp).onSizeChanged { h = it.height.coerceAtLeast(1) }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val d = awaitFirstDown()
                    jump(d.position.y)
                    d.consume()
                    do {
                        val e = awaitPointerEvent()
                        val c = e.changes.firstOrNull()
                        if (c != null) { jump(c.position.y); c.consume() }
                    } while (e.changes.any { it.pressed })
                }
            },
        verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally
    ) { letters.forEach { Text(it.toString(), fontSize = 10.sp, color = Mute) } }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongRow(a: App, s: Song, i: Int, list: List<Song>) {
    val on = a.curId == s.id
    val picked = s.id in a.sel
    Row(
        Modifier.fillMaxWidth().clip(R16).background(if (picked) Color(0xFF12305E) else CardC)
            .border(1.dp, if (on) Red else if (picked) Cyan else LineC, R16)
            .combinedClickable(
                onClick = { if (a.sel.isNotEmpty()) a.toggleSel(s.id) else { a.playList(list, i); a.expanded = true } },
                onLongClick = { a.toggleSel(s.id) }
            ).padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(if (on) Brush.linearGradient(listOf(Red, Red)) else Brush.linearGradient(listOf(Blue, Cyan))),
            contentAlignment = Alignment.Center
        ) { Icon(if (picked) Icons.Rounded.Check else Icons.Rounded.MusicNote, null, tint = if (on) Color.White else Dark) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(s.artist + " - " + s.album, fontSize = 12.sp, color = Mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = { a.toggleFav(s.id) }, modifier = Modifier.size(40.dp)) {
            Icon(if (s.id in a.favs) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favourite", tint = if (s.id in a.favs) Red else Mute, modifier = Modifier.size(20.dp))
        }
        IconButton(onClick = { a.sheet = Sheet.Menu(s) }, modifier = Modifier.size(40.dp)) { Icon(Icons.Rounded.MoreVert, "More options", tint = Mute) }
    }
}

@Composable
fun PlaylistsView(a: App) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Button(onClick = { a.sheet = Sheet.NewPl(emptyList()) }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Dark)) { Text("+ New playlist", fontWeight = FontWeight.Bold) }
        }
        if (a.lists.isEmpty()) item { Text("No playlists yet", color = Mute, fontSize = 14.sp, modifier = Modifier.padding(top = 12.dp)) }
        items(a.lists.keys.toList()) { name ->
            Row(
                Modifier.fillMaxWidth().clip(R16).background(CardC).border(1.dp, LineC, R16).clickable { a.openList = name }.padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.QueueMusic, null, tint = Cyan)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${a.lists[name]?.size ?: 0} songs", fontSize = 12.sp, color = Mute)
                }
                IconButton(onClick = { a.deletePlaylist(name) }) { Icon(Icons.Rounded.Delete, "Delete playlist", tint = Mute) }
            }
        }
    }
}

@Composable
fun MiniBar(a: App, mod: Modifier) {
    val p = if (a.dur > 0) (a.pos.toFloat() / a.dur).coerceIn(0f, 1f) else 0f
    Row(
        mod.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF111A30))
            .border(1.dp, LineC, RoundedCornerShape(22.dp)).clickable { a.expanded = true }.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Blue, Cyan))), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.MusicNote, null, tint = Dark, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(a.title, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Box(Modifier.size(50.dp).clip(CircleShape).clickable { if (a.playing) a.ctl?.pause() else a.ctl?.play() }, contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(3.dp)) {
                val w = 3.dp.toPx()
                drawArc(color = Color(0xFF16213D), startAngle = -90f, sweepAngle = 360f, useCenter = false, style = Stroke(width = w))
                drawArc(color = Cyan, startAngle = -90f, sweepAngle = 360f * p, useCenter = false, style = Stroke(width = w, cap = StrokeCap.Round))
            }
            Icon(if (a.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play or pause", tint = Cyan)
        }
        IconButton(onClick = { a.ctl?.seekToNext() }) { Icon(Icons.Rounded.SkipNext, "Next", tint = Cyan) }
        IconButton(onClick = { a.sheet = Sheet.QueueL }) { Icon(Icons.Rounded.QueueMusic, "Queue", tint = Color.White) }
    }
}

@Composable
fun RoundBtn(size: Int, round: Boolean, border: Color, bg: Brush, onClick: () -> Unit, content: @Composable () -> Unit) {
    val sh = if (round) CircleShape else RoundedCornerShape(14.dp)
    Box(Modifier.size(size.dp).clip(sh).background(bg).border(2.dp, border, sh).clickable(onClick = onClick), contentAlignment = Alignment.Center) { content() }
}

@Composable
fun FullPlayer(a: App) {
    var tabC by remember { mutableIntStateOf(0) }
    var angle by remember { mutableFloatStateOf(0f) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(a.playing) { while (a.playing) { angle = (angle + 0.5f) % 360f; delay(16) } }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val cur = a.curId?.let { a.byId[it] }
    val fav = a.curId?.let { it in a.favs } ?: false
    val flat = Brush.linearGradient(listOf(Color(0xFF101A33), Color(0xFF101A33)))
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(colors = listOf(Color(0xFF0B1C4D), Bg), endY = 1400f)).pointerInput(Unit) { detectTapGestures { } }
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onClick = { a.expanded = false }) { Icon(Icons.Rounded.KeyboardArrowDown, "Minimize player", tint = Color.White, modifier = Modifier.size(32.dp)) }
            Row(Modifier.clip(RoundedCornerShape(999.dp)).background(CardC).border(1.dp, LineC, RoundedCornerShape(999.dp)).padding(4.dp)) {
                listOf("COVER", "LYRIC").forEachIndexed { i, t ->
                    Text(t, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (tabC == i) Color.White else Mute,
                        modifier = Modifier.clip(RoundedCornerShape(999.dp)).background(if (tabC == i) LineC else Color.Transparent).clickable { tabC = i }.padding(horizontal = 22.dp, vertical = 8.dp))
                }
            }
            IconButton(onClick = { cur?.let { a.sheet = Sheet.Menu(it) } }) { Icon(Icons.Rounded.MoreVert, "More options", tint = Color.White) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp).clip(R28).background(CardC).border(1.dp, LineC, R28), contentAlignment = Alignment.Center) {
            if (tabC == 0) {
                BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    val d = (if (maxWidth < maxHeight) maxWidth else maxHeight) - 36.dp
                    Box(
                        Modifier.size(if (d < 120.dp) 120.dp else d).rotate(angle).clip(CircleShape)
                            .background(Brush.sweepGradient(listOf(Color(0xFF0A0F1D), Color(0xFF123A8F), Color(0xFF0A0F1D), Color(0xFF0AB8D1), Color(0xFF0A0F1D), Color(0xFF7A1230), Color(0xFF0A0F1D))))
                            .border(3.dp, if (a.playing) Cyan else LineC, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.fillMaxSize(0.35f).clip(CircleShape).background(Red), contentAlignment = Alignment.Center) { Box(Modifier.size(10.dp).clip(CircleShape).background(Bg)) }
                    }
                }
            } else {
                Text("Lyrics aren’t available for this song yet.", color = Mute, fontSize = 15.sp, modifier = Modifier.padding(24.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 12.dp, top = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(a.title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(a.artist, fontSize = 15.sp, color = Mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = { a.curId?.let { a.toggleFav(it) } }) { Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favourite", tint = Red, modifier = Modifier.size(30.dp)) }
        }
        Slider(
            value = if (a.dur > 0) (a.pos.toFloat() / a.dur).coerceIn(0f, 1f) else 0f,
            onValueChange = { a.drag = true; a.pos = (it * a.dur).toLong() },
            onValueChangeFinished = { a.ctl?.seekTo(a.pos); a.drag = false },
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF16213D)),
            modifier = Modifier.padding(horizontal = 14.dp)
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(a.pos), color = Mute, fontSize = 12.sp)
            Text(fmt(a.dur), color = Mute, fontSize = 12.sp)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            RoundBtn(44, false, if (a.shuffle) Cyan else LineC, flat, { a.ctl?.setShuffleModeEnabled(!a.shuffle) }) { Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (a.shuffle) Cyan else Mute) }
            RoundBtn(58, true, Cyan, flat, { a.ctl?.seekToPrevious() }) { Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Cyan, modifier = Modifier.size(30.dp)) }
            RoundBtn(80, true, Color.Transparent, Brush.linearGradient(listOf(Color(0xFF8FF6FF), Cyan, Color(0xFF0AA9C4))), { if (a.playing) a.ctl?.pause() else a.ctl?.play() }) {
                Icon(if (a.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play or pause", tint = Dark, modifier = Modifier.size(40.dp))
            }
            RoundBtn(58, true, Cyan, flat, { a.ctl?.seekToNext() }) { Icon(Icons.Rounded.SkipNext, "Next", tint = Cyan, modifier = Modifier.size(30.dp)) }
            RoundBtn(44, false, LineC, flat, { a.sheet = Sheet.QueueL }) { Icon(Icons.Rounded.QueueMusic, "Queue", tint = Mute) }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
            Chip(listOf("Repeat: off", "Repeat: all", "Repeat: one")[a.rep.coerceIn(0, 2)], a.rep != 0) {
                a.ctl?.setRepeatMode(when (a.rep) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF })
            }
            Chip(if (Sleep.endAt > 0) "Sleep ${((Sleep.endAt - now) / 60000 + 1).coerceAtLeast(1)} min" else "Sleep timer", Sleep.endAt > 0) { a.sheet = Sheet.SleepT }
            Chip("Equalizer", false) { a.sheet = Sheet.Equal }
        }
    }
}

@Composable
fun MI(icon: ImageVector, text: String, tint: Color = Color.White, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(18.dp))
        Text(text, fontSize = 17.sp, color = tint, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SheetHost(a: App) {
    val sh = a.sheet
    if (sh is Sheet.NewPl) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { a.sheet = null }, containerColor = SheetC, titleContentColor = Color.White, textContentColor = Color.White,
            title = { Text("New playlist") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, placeholder = { Text("Playlist name", color = Mute) }) },
            confirmButton = {
                TextButton(onClick = {
                    val n = name.trim()
                    if (n.isNotEmpty()) { a.addToPlaylist(n, sh.ids); a.sheet = null; a.sel = emptySet() }
                }) { Text("Create", color = Cyan) }
            },
            dismissButton = { TextButton(onClick = { a.sheet = null }) { Text("Cancel", color = Mute) } }
        )
    } else if (sh != null) {
        ModalBottomSheet(onDismissRequest = { a.sheet = null }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = SheetC, contentColor = Color.White) {
            when (sh) {
                is Sheet.Menu -> MenuSheet(a, sh.s)
                is Sheet.SortBy -> SortSheet(a)
                is Sheet.SleepT -> SleepSheet(a)
                is Sheet.Equal -> EqSheet(a)
                is Sheet.QueueL -> QueueSheet(a)
                is Sheet.AddTo -> AddToSheet(a, sh.ids)
                is Sheet.NewPl -> {}
            }
        }
    }
    a.info?.let { s ->
        AlertDialog(
            onDismissRequest = { a.info = null }, containerColor = SheetC, titleContentColor = Color.White, textContentColor = Color.White,
            title = { Text("Song info") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Title" to s.title, "Artist" to s.artist, "Album" to s.album, "Duration" to fmt(s.dur), "Size" to "%.1f MB".format(s.size / 1048576.0), "File" to s.file, "Path" to s.path).forEach { (k, v) ->
                        Column { Text(k, fontSize = 12.sp, color = Mute); Text(v, fontSize = 14.sp) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { a.info = null }) { Text("Close", color = Cyan) } }
        )
    }
}

@Composable
fun MenuSheet(a: App, s: Song) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Text("Cancel", color = Red, fontSize = 17.sp, modifier = Modifier.clickable { a.sheet = null }.padding(horizontal = 24.dp, vertical = 10.dp))
        MI(Icons.Rounded.SkipNext, "Play next") { a.sheet = null; a.playNext(s) }
        MI(Icons.Rounded.QueueMusic, "Add to play queue") { a.sheet = null; a.addQueue(s) }
        MI(Icons.Rounded.PlaylistAdd, "Add to Playlist") { a.sheet = Sheet.AddTo(listOf(s.id)) }
        MI(Icons.Rounded.Album, "Album: " + s.album) { a.sheet = null; a.tab = 0; a.openList = null; a.q = s.album }
        MI(Icons.Rounded.Info, "Song Info") { a.sheet = null; a.info = s }
        MI(Icons.Rounded.NotificationsActive, "Set Ringtone") { a.sheet = null; a.ringtone(s) }
        MI(Icons.Rounded.Share, "Share local file") { a.sheet = null; a.share(s) }
        MI(Icons.Rounded.Delete, "Delete") { a.sheet = null; a.deleteSongs(listOf(s)) }
    }
}

@Composable
fun SortSheet(a: App) {
    Column(Modifier.padding(bottom = 24.dp)) {
        Text("Sort by", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
        listOf("Name (A–Z)", "Artist", "Newest first", "Oldest first").forEachIndexed { i, n ->
            MI(if (a.sort == i) Icons.Rounded.Check else Icons.Rounded.Sort, n, if (a.sort == i) Cyan else Color.White) { a.sort = i; a.store.sort = i; a.sheet = null }
        }
    }
}

@Composable
fun SleepSheet(a: App) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Text("Sleep timer", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
        listOf(15, 30, 45, 60).forEach { m -> MI(Icons.Rounded.Timer, "$m minutes") { Sleep.start(m); a.sheet = null; a.toast("Music will stop in $m minutes") } }
        if (Sleep.endAt > 0) MI(Icons.Rounded.Close, "Turn off timer", Red) { Sleep.cancel(); a.sheet = null }
    }
}

@Composable
fun EqSheet(a: App) {
    val eq = PlayerService.eq
    Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 24.dp).padding(bottom = 28.dp)) {
        Text("Equalizer", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        if (eq == null) {
            Spacer(Modifier.height(12.dp))
            Text("The equalizer isn’t ready yet. Play a song first, then open this again.", color = Mute)
        } else {
            val n = eq.numberOfBands.toInt()
            val lo = eq.bandLevelRange[0].toFloat()
            val hi = eq.bandLevelRange[1].toFloat()
            val lv = remember { mutableStateListOf<Int>().also { l -> for (i in 0 until n) l.add(eq.getBandLevel(i.toShort()).toInt()) } }
            var on by remember { mutableStateOf(eq.getEnabled()) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Enabled", modifier = Modifier.weight(1f))
                Switch(checked = on, onCheckedChange = { on = it; eq.setEnabled(it); a.store.saveEq(lv.toList(), it) }, colors = SwitchDefaults.colors(checkedTrackColor = Cyan, checkedThumbColor = Dark))
            }
            for (i in 0 until n) {
                Text(hz(eq.getCenterFreq(i.toShort())), color = Mute, fontSize = 13.sp)
                Slider(
                    value = lv[i].toFloat().coerceIn(lo, hi),
                    onValueChange = { v -> lv[i] = v.toInt(); eq.setBandLevel(i.toShort(), v.toInt().toShort()) },
                    onValueChangeFinished = { a.store.saveEq(lv.toList(), on) },
                    valueRange = lo..hi,
                    colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF16213D))
                )
            }
            TextButton(onClick = { for (i in 0 until n) { lv[i] = 0; eq.setBandLevel(i.toShort(), 0.toShort()) }; a.store.saveEq(lv.toList(), on) }) { Text("Reset", color = Cyan) }
        }
    }
}

@Composable
fun QueueSheet(a: App) {
    Column(Modifier.padding(bottom = 16.dp)) {
        Text("Queue (${a.queue.size})", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
        LazyColumn(Modifier.heightIn(max = 460.dp)) {
            itemsIndexed(a.queue) { i, m ->
                val on = m.mediaId == a.curId?.toString()
                Row(Modifier.fillMaxWidth().clickable { a.ctl?.seekTo(i, 0L); a.ctl?.play() }.padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}", color = if (on) Red else Mute, modifier = Modifier.width(36.dp))
                    Column {
                        Text(m.mediaMetadata.title?.toString() ?: "", color = if (on) Cyan else Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(m.mediaMetadata.artist?.toString() ?: "", color = Mute, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun AddToSheet(a: App, ids: List<Long>) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Text("Add to playlist", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
        MI(Icons.Rounded.Add, "New playlist", Cyan) { a.sheet = Sheet.NewPl(ids) }
        a.lists.keys.toList().forEach { name ->
            MI(Icons.Rounded.QueueMusic, name) { a.addToPlaylist(name, ids); a.sheet = null; a.sel = emptySet(); a.toast("Added to $name") }
        }
    }
}
