package com.play.music

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private lateinit var app: App

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { window.attributes = window.attributes.apply { preferredRefreshRate = 120f } } catch (e: Exception) {}
        app = App(this, Store(this))
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { PlayApp(app) } }
    }

    override fun onStart() {
        super.onStart()
        app.startTick++
    }

    override fun onStop() {
        app.miniShown = false
        app.saveState()
        super.onStop()
    }
}

@Composable
fun PlayerHost(a: App) {
    if (a.exp.value > 0.001f) FullPlayer(a)
}

@Composable
fun NoteHost(a: App, scope: BoxScope) {
    with(scope) {
        AnimatedVisibility(
            visible = a.noteOn,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 120.dp),
            enter = fadeIn(tween(300)), exit = fadeOut(tween(450))
        ) {
            Text(
                a.noteText, color = Cyan, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(999.dp)).background(Color(0xFF111A30)).border(androidx.compose.foundation.BorderStroke(1.dp, Cyan.copy(alpha = 0.6f)), RoundedCornerShape(999.dp)).padding(horizontal = 18.dp, vertical = 10.dp)
            )
        }
    }
}

private fun depthOf(p: String?): Int = when (p) { null -> 0; "settings" -> 1; else -> 2 }

@Composable
fun PagesHost(a: App) {
    AnimatedContent(
        targetState = a.page, label = "pages",
        transitionSpec = {
            if (depthOf(targetState) > depthOf(initialState))
                (slideInHorizontally(tween(330, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(220))) togetherWith (slideOutHorizontally(tween(330, easing = FastOutSlowInEasing)) { -it / 4 } + fadeOut(tween(220)))
            else
                (slideInHorizontally(tween(330, easing = FastOutSlowInEasing)) { -it / 4 } + fadeIn(tween(220))) togetherWith (slideOutHorizontally(tween(330, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(220)))
        }
    ) { p ->
        when (p) {
            "settings" -> SettingsPage(a)
            "look" -> LookPage(a)
            "widget" -> WidgetPage(a)
            "about" -> AboutPage(a)
            else -> androidx.compose.foundation.layout.Spacer(Modifier.size(0.dp))
        }
    }
}

@Composable
fun PlayApp(a: App) {
    val ctx = LocalContext.current
    a.scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[a.perm] == true) { a.granted = true; a.reload() }
    }
    a.delLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) a.finishDelete() else a.pendingDelete = emptyList()
    }
    a.askPerm = { launcher.launch(arrayOf(a.perm)) }

    LaunchedEffect(Unit) {
        if (a.hasPerm()) {
            a.reload()
        } else {
            a.loaded = true
            launcher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(a.perm, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(a.perm))
        }
    }
    DisposableEffect(Unit) {
        val f = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlayerService::class.java))).buildAsync()
        f.addListener({ a.attach(f.get()) }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(f) }
    }
    LaunchedEffect(a.ctl) {
        var tick = 0
        while (true) {
            val c = a.ctl
            if (!a.drag) a.pos = c?.currentPosition ?: 0L
            if (c != null && c.isPlaying) {
                val id = a.curId
                if (id != null && a.counted != id && a.pos > 15000L) { a.counted = id; a.bump(id) }
                tick++
                if (tick % 20 == 0) a.saveState()
            }
            delay(250)
        }
    }
    LaunchedEffect(a.startTick, a.curId != null, a.ready) {
        if (a.curId != null && a.ready) {
            val wait = 1100L - (System.currentTimeMillis() - a.readyAt)
            delay(if (wait > 260L) wait else 260L)
            a.miniShown = true
        }
    }
    BackHandler(enabled = a.exp.value > 0.5f) { a.collapse() }
    BackHandler(enabled = a.exp.value <= 0.5f && a.sel.isNotEmpty()) { a.sel = emptySet() }
    BackHandler(enabled = a.exp.value <= 0.5f && a.sel.isEmpty() && a.searching) { a.q = ""; a.searching = false }
    BackHandler(enabled = a.exp.value <= 0.5f && a.sel.isEmpty() && !a.searching && (a.openList != null || a.openFolder != null)) { a.openList = null; a.openFolder = null }
    BackHandler(enabled = a.page != null) { a.page = if (a.page == "settings") null else "settings" }

    var showSplash by remember { mutableStateOf(true) }
    val density = LocalDensity.current
    CompositionLocalProvider(LocalContentColor provides Color.White) {
        BoxWithConstraints(Modifier.fillMaxSize().background(bgBrush())) {
            SideEffect { a.hPx = with(density) { maxHeight.toPx() } }
            MainScreen(a)
            AnimatedVisibility(
                visible = a.curId != null && a.miniShown,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically(spring(dampingRatio = 0.8f, stiffness = 300f)) { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut()
            ) { MiniBar(a, Modifier) }
            PlayerHost(a)
            PagesHost(a)
            SheetHost(a)
            NoteHost(a, this)
            if (showSplash) Splash {
                showSplash = false
                a.readyAt = System.currentTimeMillis()
                a.stamp = a.readyAt
                a.ready = true
            }
        }
    }
}
