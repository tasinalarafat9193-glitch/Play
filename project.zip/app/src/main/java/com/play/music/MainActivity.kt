package com.play.music

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay

val Bg = Color(0xFF04060C)
val CardC = Color(0xFF0C1220)
val LineC = Color(0xFF1A2540)
val Blue = Color(0xFF2563FF)
val Cyan = Color(0xFF22E6FF)
val Red = Color(0xFFFF2D55)
val Mute = Color(0xFF8592B0)

data class Song(val id: Long, val title: String, val artist: String, val uri: Uri)

fun loadSongs(c: Context): List<Song> {
    val out = mutableListOf<Song>()
    val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST
    )
    c.contentResolver.query(
        base, proj,
        MediaStore.Audio.Media.DURATION + " >= 30000", null,
        MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC"
    )?.use { cur ->
        val i = cur.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val t = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val a = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        while (cur.moveToNext()) {
            val id = cur.getLong(i)
            val artist = cur.getString(a) ?: "Unknown artist"
            out.add(Song(id, cur.getString(t) ?: "Unknown", if (artist == "<unknown>") "Unknown artist" else artist, ContentUris.withAppendedId(base, id)))
        }
    }
    return out
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { PlayApp() } }
    }
}

@Composable
fun Btn(size: Dp, shape: Shape, bg: Brush, border: Color, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(size).clip(shape).background(bg).border(2.dp, border, shape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
fun PlayApp() {
    val ctx = LocalContext.current
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var granted by remember { mutableStateOf(false) }
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[perm] == true) { granted = true; songs = loadSongs(ctx) }
    }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED) {
            granted = true; songs = loadSongs(ctx)
        } else {
            launcher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(perm, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(perm))
        }
    }

    var ctl by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val token = SessionToken(ctx, ComponentName(ctx, PlayerService::class.java))
        val f = MediaController.Builder(ctx, token).buildAsync()
        f.addListener({ ctl = f.get() }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(f) }
    }

    var playing by remember { mutableStateOf(false) }
    var cur by remember { mutableIntStateOf(-1) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var shuffle by remember { mutableStateOf(false) }
    var rep by remember { mutableIntStateOf(0) }
    var drag by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var angle by remember { mutableFloatStateOf(0f) }

    DisposableEffect(ctl) {
        val c = ctl
        val l = object : Player.Listener {
            override fun onEvents(p: Player, e: Player.Events) {
                playing = p.isPlaying
                cur = if (p.mediaItemCount > 0) p.currentMediaItemIndex else -1
                dur = maxOf(p.duration, 0L)
                shuffle = p.shuffleModeEnabled
                rep = p.repeatMode
            }
        }
        c?.addListener(l)
        onDispose { c?.removeListener(l) }
    }
    LaunchedEffect(ctl) {
        while (true) {
            if (!drag) pos = ctl?.currentPosition ?: 0L
            delay(500)
        }
    }
    LaunchedEffect(playing) {
        while (playing) { angle = (angle + 0.5f) % 360f; delay(16) }
    }

    fun playAt(i: Int) {
        val c = ctl ?: return
        if (c.mediaItemCount == songs.size && songs.isNotEmpty()) {
            c.seekTo(i, 0L)
        } else {
            val items = songs.map {
                MediaItem.Builder().setMediaId(it.id.toString()).setUri(it.uri)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).setArtist(it.artist).build()).build()
            }
            c.setMediaItems(items, i, 0L)
        }
        c.prepare()
        c.play()
    }

    val shown = songs.withIndex().filter { q.isBlank() || it.value.title.contains(q, true) || it.value.artist.contains(q, true) }
    val song = songs.getOrNull(cur)

    Surface(color = Bg, contentColor = Color.White, modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(colors = listOf(Color(0xFF0B1C4D), Bg), endY = 1400f)).statusBarsPadding()) {
            LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Row { Text("Play", color = Cyan, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold); Text(".", color = Red, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold) }
                    Spacer(Modifier.height(14.dp))
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(CardC).border(1.dp, LineC, RoundedCornerShape(28.dp)).padding(horizontal = 20.dp, vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.size(200.dp).rotate(angle).clip(CircleShape)
                                .background(Brush.sweepGradient(listOf(Color(0xFF0A0F1D), Color(0xFF123A8F), Color(0xFF0A0F1D), Color(0xFF0AB8D1), Color(0xFF0A0F1D), Color(0xFF7A1230), Color(0xFF0A0F1D))))
                                .border(3.dp, if (playing) Cyan else LineC, CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Box(Modifier.size(60.dp).clip(CircleShape).background(Red)) }
                        Spacer(Modifier.height(18.dp))
                        Text(song?.title ?: "No song selected", fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(song?.artist ?: "Pick a song from your library", color = Mute, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Slider(
                            value = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f,
                            onValueChange = { drag = true; pos = (it * dur).toLong() },
                            onValueChangeFinished = { ctl?.seekTo(pos); drag = false },
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Cyan, inactiveTrackColor = Color(0xFF16213D))
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(fmt(pos), color = Mute, fontSize = 12.sp)
                            Text(fmt(dur), color = Mute, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Btn(44.dp, RoundedCornerShape(14.dp), SolidColor(Color(0xFF111A30)), if (shuffle) Cyan else LineC, { ctl?.setShuffleModeEnabled(!shuffle) }) {
                                Icon(Icons.Rounded.Shuffle, null, tint = if (shuffle) Cyan else Mute)
                            }
                            Btn(58.dp, CircleShape, SolidColor(Color(0xFF101A33)), Cyan, { ctl?.seekToPrevious() }) {
                                Icon(Icons.Rounded.SkipPrevious, null, tint = Cyan, modifier = Modifier.size(30.dp))
                            }
                            Btn(80.dp, CircleShape, Brush.linearGradient(listOf(Color(0xFF8FF6FF), Cyan, Color(0xFF0AA9C4))), Color.Transparent, {
                                if (cur < 0) { if (songs.isNotEmpty()) playAt(0) } else if (playing) ctl?.pause() else ctl?.play()
                            }) {
                                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color(0xFF021022), modifier = Modifier.size(40.dp))
                            }
                            Btn(58.dp, CircleShape, SolidColor(Color(0xFF101A33)), Cyan, { ctl?.seekToNext() }) {
                                Icon(Icons.Rounded.SkipNext, null, tint = Cyan, modifier = Modifier.size(30.dp))
                            }
                            Btn(44.dp, RoundedCornerShape(14.dp), SolidColor(Color(0xFF111A30)), if (rep != 0) Cyan else LineC, {
                                ctl?.setRepeatMode(when (rep) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF })
                            }) {
                                Icon(if (rep == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, null, tint = if (rep != 0) Cyan else Mute)
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                        Text("Library", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("${songs.size} songs", color = Mute, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = q, onValueChange = { q = it }, singleLine = true,
                        placeholder = { Text("Search songs", color = Mute) },
                        leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Mute) },
                        shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan, unfocusedBorderColor = LineC,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan
                        )
                    )
                }
                if (songs.isEmpty()) {
                    item {
                        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (granted) "No songs found on this phone" else "Allow access to your music to see your songs", color = Mute, fontSize = 14.sp)
                            if (!granted) {
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = { launcher.launch(arrayOf(perm)) }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Color(0xFF021022))) { Text("Allow access") }
                            }
                        }
                    }
                }
                items(shown, key = { it.value.id }) { iv ->
                    val on = iv.index == cur
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardC)
                            .border(1.dp, if (on) Red else LineC, RoundedCornerShape(16.dp))
                            .clickable { playAt(iv.index) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(38.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (on) SolidColor(Red) else Brush.linearGradient(listOf(Blue, Cyan))),
                            contentAlignment = Alignment.Center
                        ) { Text("${iv.index + 1}", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = if (on) Color.White else Color(0xFF021022)) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(iv.value.title, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(iv.value.artist, fontSize = 12.sp, color = Mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}
